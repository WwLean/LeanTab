let confirmResolver=null;
function customConfirm(message,{title=tr('Подтвердите действие'),okText=tr('Продолжить'),danger=false}={}){
  const modal=$('confirmModal');$('confirmTitle').textContent=title;$('confirmText').textContent=message;$('confirmOk').textContent=okText;$('confirmOk').classList.toggle('dangerButton',danger);$('confirmOk').classList.toggle('primaryButton',!danger);
  if(modal.open)modal.close();modal.showModal();requestAnimationFrame(()=>modal.classList.add('is-open'));
  return new Promise(resolve=>{confirmResolver=resolve});
}
function finishConfirm(value){const modal=$('confirmModal');modal.classList.remove('is-open');setTimeout(()=>{if(modal.open)modal.close()},160);const resolve=confirmResolver;confirmResolver=null;resolve?.(value)}

let importModeResolver=null;
function chooseImportMode(){
  const modal=$('importModeModal');
  if(modal.open)modal.close();
  modal.querySelector('input[value="replace"]').checked=true;
  modal.showModal();requestAnimationFrame(()=>modal.classList.add('is-open'));
  return new Promise(resolve=>{importModeResolver=resolve});
}
function finishImportMode(value){
  const modal=$('importModeModal');modal.classList.remove('is-open');setTimeout(()=>{if(modal.open)modal.close()},160);
  const resolve=importModeResolver;importModeResolver=null;resolve?.(value);
}
$('importModeForm').onsubmit=e=>{e.preventDefault();finishImportMode(new FormData(e.currentTarget).get('importMode')||'replace')};
$('cancelImportMode').onclick=$('closeImportMode').onclick=()=>finishImportMode(null);
$('importModeModal').addEventListener('cancel',e=>{e.preventDefault();finishImportMode(null)});
$('importModeModal').addEventListener('click',e=>{if(e.target===$('importModeModal'))finishImportMode(null)});

$('confirmCancel').onclick=()=>finishConfirm(false);$('confirmOk').onclick=()=>finishConfirm(true);$('confirmModal').addEventListener('cancel',e=>{e.preventDefault();finishConfirm(false)});$('confirmModal').addEventListener('click',e=>{if(e.target===$('confirmModal'))finishConfirm(false)});
if($('settingsVersion'))$('settingsVersion').textContent=`LeanTab ${APP_VERSION}`;
$('settingsBtn').onclick=()=>{if($('settingsModal').open)return;window.resetSettingsSearch?.();settingsSnapshot=structuredClone(config);settingsDirty=false;$('saveSettingsBtn').classList.remove('save-attention');syncSettings();stopAnimation();$('settingsModal').showModal();requestAnimationFrame(()=>$('settingsModal').classList.add('is-open'));setTimeout(()=>$('closeSettings').focus(),80)};
function animateUnsaved(){const card=$('settingsForm'),btn=$('saveSettingsBtn');card.classList.remove('unsaved-shake');btn.classList.remove('save-attention');void card.offsetWidth;card.classList.add('unsaved-shake');btn.classList.add('save-attention');setTimeout(()=>card.classList.remove('unsaved-shake'),420)}
function finishCloseSettings(){window.resetSettingsSearch?.();$('settingsModal').classList.remove('is-open');setTimeout(()=>{if($('settingsModal').open)$('settingsModal').close();restartAnimation()},240)}
function discardSettings(){if(settingsSnapshot){config=structuredClone(settingsSnapshot);setLanguage(config.settings.language);apply()}settingsSnapshot=null;settingsDirty=false;finishCloseSettings()}
async function requestCloseSettings(){if(!settingsDirty){discardSettings();return}animateUnsaved();if(await customConfirm(tr('Есть несохранённые изменения. Закрыть без сохранения?'),{okText:tr('Закрыть без сохранения')}))discardSettings()}
$('closeSettings').onclick=$('cancelSettings').onclick=requestCloseSettings;
$('settingsModal').addEventListener('click',e=>{if(e.target===$('settingsModal'))requestCloseSettings()});
$('settingsModal').addEventListener('cancel',e=>{e.preventDefault();requestCloseSettings()});
$('settingsForm').onsubmit=async e=>{e.preventDefault();readSettings();try{await persistAssetsFromConfig();if(!await save())return;apply();settingsSnapshot=null;settingsDirty=false;$('saveSettingsBtn').classList.remove('save-attention');finishCloseSettings();toast(tr('Настройки сохранены'),'success')}catch(err){console.error('Settings save failed',err);toast(tr('Не удалось сохранить настройки'),'error')}};
document.querySelectorAll('[data-add-zone]').forEach(button=>button.onclick=()=>openTile(null,'link',button.dataset.addZone));
document.querySelector('#searchForm kbd')?.addEventListener('click',()=>{$('searchInput').focus();$('searchInput').select()});
document.querySelector('#searchForm kbd')?.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('searchInput').focus();$('searchInput').select()}});
document.querySelector('#searchForm kbd')?.setAttribute('tabindex','0');
document.querySelector('#searchForm kbd')?.setAttribute('role','button');
document.querySelector('#searchForm kbd')?.setAttribute('aria-label',tr('Перейти к строке поиска'));$('closeTileModal').onclick=$('cancelTile').onclick=closeTile;$('tileModal').addEventListener('click',e=>{if(e.target===$('tileModal'))closeTile()});$('tileModal').addEventListener('cancel',e=>{e.preventDefault();closeTile()});$('iconMode').onchange=toggleIconRows;['tileTitle','tileUrl','tileEmoji','tileColor','quickFolderName','quickFolderColor'].forEach(id=>$(id).addEventListener('input',previewTile));
$('tileIconFile').onchange=e=>{const f=e.target.files[0];if(!f)return;if(!IMAGE_TYPES.has(f.type)){toast(tr('Поддерживаются JPG, PNG, WEBP и GIF'),'error');e.target.value='';return}if(f.size>ICON_MAX_BYTES){toast(tr('Иконка слишком большая: максимум 3 МБ'),'error');e.target.value='';return}const r=new FileReader();r.onerror=()=>toast(tr('Не удалось прочитать изображение'),'error');r.onload=()=>{uploadedIcon=String(r.result||'');previewTile()};r.readAsDataURL(f)};
$('tileForm').onsubmit=async e=>{e.preventDefault();
  if(window.currentCreateMode==='folder'&&!editingId){
    const name=safeText($('quickFolderName').value,32); if(!name){toast(tr('Введите название папки'),'error');$('quickFolderName').focus();return}
    const before=structuredClone(config.folders);config.folders.push({id:uid(),name,zone:ZONES.includes($('quickFolderZone').value)?$('quickFolderZone').value:'bottom',color:validColor($('quickFolderColor').value)});
    if(!await save()){config.folders=before;renderLinks();return} renderLinks(); closeTile(); toast(tr('Папка создана'),'success'); return;
  }
  const title=safeText($('tileTitle').value,32), rawUrl=$('tileUrl').value.trim();if(!title||!rawUrl){toast(tr('Заполните название и адрес'),'error');return}
  let url;try{url=new URL(normalizeUrl(rawUrl));if(!['http:','https:'].includes(url.protocol))throw new Error()}catch{toast(tr('Введите корректный адрес сайта'),'error');$('tileUrl').focus();return}
  const item={id:editingId||uid(),title,url:url.href,folderId:$('tileFolder').value||'',zone:ZONES.includes($('tileZone').value)?$('tileZone').value:'bottom',iconMode:['favicon','emoji','initials','upload'].includes($('iconMode').value)?$('iconMode').value:'favicon',emoji:safeText($('tileEmoji').value,8),color:validColor($('tileColor').value)};
  const previous=editingId?config.links.find(x=>x.id===editingId):null;
  try{
    const oldIconData=previous?.iconMode==='upload'?(previous.iconData||await assetGet('icon:'+item.id).catch(()=>'')):'';
    if(item.iconMode==='upload'){item.iconData=uploadedIcon||oldIconData;if(!item.iconData){toast(tr('Выберите изображение для иконки'),'error');return}await assetSet('icon:'+item.id,item.iconData)}
    const before=structuredClone(config.links);if(editingId){const idx=config.links.findIndex(x=>x.id===editingId);if(idx<0)throw new Error('Link not found');config.links[idx]=item}else config.links.push(item);
    if(!await save()){
      config.links=before;
      if(item.iconMode==='upload'){if(oldIconData)await assetSet('icon:'+item.id,oldIconData).catch(()=>{});else await assetDelete('icon:'+item.id).catch(()=>{})}
      renderLinks();return
    }
    if(item.iconMode!=='upload'&&previous?.iconMode==='upload')await assetDelete('icon:'+item.id).catch(()=>{});
    renderLinks();closeTile();toast(tr('Ссылка сохранена'),'success')
  }catch(err){console.error('Tile save failed',err);toast(tr('Не удалось сохранить ссылку'),'error')}
};
$('deleteTile').onclick=async()=>{if(!editingId)return;const link=config.links.find(x=>x.id===editingId);if(link&&await customConfirm(tr('Удалить эту ссылку?'),{title:tr('Удаление ссылки'),okText:tr('Удалить'),danger:true})){const id=link.id,before=structuredClone(config.links);config.links=config.links.filter(x=>x.id!==id);if(!await save()){config.links=before;renderLinks();return}await assetDelete('icon:'+id).catch(()=>{});await closeTileAndWait();await animateTileRemoval(id);toast(tr('Ссылка удалена'),'success')}};
$('bgFile').onchange=e=>{const f=e.target.files[0];if(!f)return;if(f.size>BG_MAX_BYTES){toast(tr('Фон слишком большой: максимум 15 МБ'),'error');e.target.value='';return}if(!IMAGE_TYPES.has(f.type)){toast(tr('Поддерживаются JPG, PNG, WEBP и GIF'),'error');e.target.value='';return}if($('bgFileName'))$('bgFileName').textContent=f.name;const r=new FileReader();r.onerror=()=>toast(tr('Не удалось прочитать изображение'),'error');r.onload=()=>{config.settings.customBg=String(r.result||'');config.settings.customBgEffects=false;config.settings.motionType='none';config.settings.overlayOpacity=0;settingsDirty=hasSettingsChanged();applyVisualSettings({restartFx:false,render:false});syncSettings();$('saveSettingsBtn').classList.toggle('save-attention',settingsDirty)};r.readAsDataURL(f)};
$('clearBg').onclick=()=>{config.settings.customBg='';$('bgFile').value='';settingsDirty=hasSettingsChanged();syncSettings();$('saveSettingsBtn').classList.toggle('save-attention',settingsDirty);applyVisualSettings({restartFx:false,render:false})};
$('exportBtn').onclick=async()=>{try{const payload={app:'LeanTab',version:APP_VERSION,formatVersion:2,exportedAt:new Date().toISOString(),config:structuredClone(config),profiles:structuredClone(profiles)};if($('backupHistory').checked)payload.searchHistory=structuredClone(searchHistory);const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));a.href=url;a.download=`leantab-${APP_VERSION}-backup-${new Date().toISOString().slice(0,10)}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast(tr('Резервная копия создана'),'success')}catch(err){console.error(err);toast(tr('Не удалось создать резервную копию'),'error')}};
$('importFile').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onerror=()=>toast(tr('Не удалось прочитать файл'),'error');r.onload=async()=>{try{const payload=JSON.parse(String(r.result||''));const raw=payload.config||payload;const mode=await chooseImportMode();if(!mode)return;const imported=mergeConfig(raw);if(mode==='merge'){const seen=new Set(config.links.map(x=>x.url));config.links.push(...imported.links.filter(x=>!seen.has(x.url)));config.folders=[...config.folders,...imported.folders.filter(f=>!config.folders.some(x=>x.name===f.name))]}else if(mode==='appearance'){config.settings=imported.settings}else if(mode==='tiles'){config.links=imported.links;config.folders=imported.folders}else config=imported;if(Array.isArray(payload.searchHistory)){searchHistory=payload.searchHistory.map(x=>typeof x==='string'?{q:x,t:Date.now()}:x);pruneSearchHistory();await chrome.storage.local.set({[SEARCH_HISTORY_KEY]:searchHistory})}if(payload.profiles&&typeof payload.profiles==='object'){profiles=payload.profiles;await chrome.storage.local.set({[PROFILES_KEY]:profiles})}await persistAssetsFromConfig();if(!await save())throw new Error('Storage save failed');settingsSnapshot=structuredClone(config);settingsDirty=false;syncSettings();apply();renderProfiles();toast(tr('Данные импортированы'),'success')}catch(err){console.error('Import failed',err);toast(tr('Не удалось импортировать файл'),'error')}finally{e.target.value=''}};r.readAsText(f)};
$('resetVisualBtn').onclick=async()=>{if(!await customConfirm(tr('Сбросить внешний вид, плитки и папки? История и профили останутся.'),{title:tr('Сброс внешнего вида'),okText:tr('Сбросить'),danger:true}))return;const before=config;const keepLanguage=config.settings.language;config=structuredClone(defaults);config.settings.language=keepLanguage;if(!await save()){config=before;return}await clearAssets().catch(err=>console.warn('Asset cleanup after reset failed',err));settingsSnapshot=structuredClone(config);syncSettings();apply();toast(tr('Внешний вид и плитки сброшены'),'success')};
$('resetBtn').onclick=async()=>{if(!await customConfirm(tr('Полностью удалить настройки, плитки, папки, историю, профили, фон и иконки LeanTab?'),{title:tr('Полная очистка'),okText:tr('Удалить всё'),danger:true}))return;try{await clearAssets();await chrome.storage.local.clear();config=structuredClone(defaults);profiles={};searchHistory=[];await save();settingsSnapshot=structuredClone(config);syncSettings();apply();renderProfiles();toast(tr('LeanTab полностью очищен'),'success')}catch(err){console.error(err);toast(tr('Не удалось очистить данные'),'error')}};
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{applyVisualSettings({restartFx:false,render:false});restartAnimation()},220)},{passive:true});
document.addEventListener('visibilitychange',()=>document.hidden?stopAnimation():restartAnimation());
prefersReducedMotion.addEventListener?.('change',()=>apply());
window.addEventListener('keydown',e=>{if(e.key==='/'&&!document.querySelector('dialog[open]')){e.preventDefault();$('searchInput').focus()}});

const ENGAGEMENT_KEY='leanTabEngagementV1';
const FEEDBACK_URL='https://leantab.help/';
const TEN_MINUTES=10*60*1000;
const REVIEW_DELAY=7*24*60*60*1000;
const REVIEW_MIN_OPENS=15;
let engagementState=null;
let engagementTimer=0;

function reviewUrl(){return `https://chrome.google.com/webstore/detail/${chrome.runtime.id}/reviews`}
function openExternal(url){try{window.open(url,'_blank','noopener,noreferrer')}catch{location.href=url}}
async function prepareEngagement(){
  try{
    const data=await chrome.storage.local.get([ENGAGEMENT_KEY,STORAGE_KEY,LEGACY_KEY]);
    engagementState=data[ENGAGEMENT_KEY]||null;
    if(!engagementState){
      const existingUser=Boolean(data[STORAGE_KEY]||data[LEGACY_KEY]);
      engagementState={installedAt:Date.now(),feedbackShown:existingUser,reviewShown:false,opens:0};
    }
    engagementState.opens=(Number(engagementState.opens)||0)+1;
    await chrome.storage.local.set({[ENGAGEMENT_KEY]:engagementState});
  }catch(err){console.warn('LeanTab engagement init failed',err);engagementState={installedAt:Date.now(),feedbackShown:true,reviewShown:true,opens:0}}
}
async function saveEngagement(){try{await chrome.storage.local.set({[ENGAGEMENT_KEY]:engagementState})}catch(err){console.warn('LeanTab engagement save failed',err)}}
function hideEngagement(){
  clearTimeout(engagementTimer);
  const card=$('engagementCard');if(!card)return;
  card.classList.remove('show');setTimeout(()=>{if(!card.classList.contains('show'))card.hidden=true},240);
}
function showEngagement(kind){
  const card=$('engagementCard');if(!card||card.classList.contains('show'))return;
  const isFeedback=kind==='feedback';
  $('engagementTitle').textContent=tr(isFeedback?'Есть вопрос или идея?':'Нравится LeanTab?');
  $('engagementText').textContent=tr(isFeedback?'Если заметили ошибку, чего-то не хватает или хотите предложить улучшение — напишите нам. Мы обязательно прочитаем и учтём ваше сообщение.':'Если LeanTab стал частью вашей новой вкладки, короткая оценка в Chrome Web Store очень поможет развитию проекта.');
  $('engagementPrimary').textContent=tr(isFeedback?'Написать нам':'Поставить оценку');
  $('engagementSecondary').textContent=tr(isFeedback?'Позже':'Есть проблема');
  card.dataset.kind=kind;card.hidden=false;requestAnimationFrame(()=>requestAnimationFrame(()=>card.classList.add('show')));
}
async function markEngagementShown(kind){
  if(!engagementState)return;
  if(kind==='feedback')engagementState.feedbackShown=true;else engagementState.reviewShown=true;
  await saveEngagement();
}
async function maybeScheduleEngagement(){
  if(!engagementState)return;
  const age=Date.now()-(Number(engagementState.installedAt)||Date.now());
  if(!engagementState.feedbackShown){
    const delay=Math.max(0,TEN_MINUTES-age);
    clearTimeout(engagementTimer);engagementTimer=setTimeout(async()=>{await markEngagementShown('feedback');showEngagement('feedback')},delay);
    return;
  }
  if(!engagementState.reviewShown&&age>=REVIEW_DELAY&&(Number(engagementState.opens)||0)>=REVIEW_MIN_OPENS){
    engagementTimer=setTimeout(async()=>{await markEngagementShown('review');showEngagement('review')},1400);
  }
}
$('engagementClose')?.addEventListener('click',hideEngagement);
$('engagementPrimary')?.addEventListener('click',()=>{const kind=$('engagementCard')?.dataset.kind;openExternal(kind==='review'?reviewUrl():FEEDBACK_URL);hideEngagement()});
$('engagementSecondary')?.addEventListener('click',()=>{const kind=$('engagementCard')?.dataset.kind;if(kind==='review')openExternal(FEEDBACK_URL);hideEngagement()});
$('feedbackBtn')?.addEventListener('click',()=>openExternal(FEEDBACK_URL));
$('rateBtn')?.addEventListener('click',()=>openExternal(reviewUrl()));

(async()=>{try{await prepareEngagement();await load();setLanguage(config.settings.language,{translateGenerated:false});buildSettingsUI();bindLiveSettings();setupDropZones();await loadProfiles();await loadSearchHistory();syncSettings();apply();await maybeScheduleEngagement()}catch(err){console.error('LeanTab startup failed',err);try{syncSettings();apply()}catch(renderErr){console.error('LeanTab fallback render failed',renderErr)}setTimeout(()=>toast(tr('LeanTab не удалось полностью запустить. Ваши сохранённые данные не удалены.'),'error'),150)}finally{requestAnimationFrame(()=>requestAnimationFrame(()=>{document.body.classList.add('ready');document.body.classList.remove('booting')}))}})();

// Emergency recovery: Ctrl+0 always restores LeanTab to 100%.
// Capture phase is used so the shortcut works even when an input or dialog is focused.
window.addEventListener('keydown',async event=>{
  const isReset=(event.ctrlKey||event.metaKey) && (event.code==='Digit0'||event.code==='Numpad0'||event.key==='0');
  if(!isReset)return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if(!config?.settings)return;
  config.settings.uiScale=100;
  document.documentElement.style.setProperty('--ui-scale','1');
  document.documentElement.style.setProperty('--ui-scale-effective','1');
  for(const element of [document.documentElement,document.body,document.querySelector('.app')]){
    if(!element)continue;
    element.style.removeProperty('zoom');
    element.style.removeProperty('scale');
    element.style.removeProperty('transform');
    element.style.removeProperty('transform-origin');
  }
  const scaleInput=document.getElementById('uiScale');
  if(scaleInput)scaleInput.value='100';
  const output=document.getElementById('uiScaleValue');
  if(output)output.value='100%';
  apply();
  await save();
  if(typeof toast==='function')toast(tr('Масштаб LeanTab восстановлен: 100%'),'success');
},true);
