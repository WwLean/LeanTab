let confirmResolver=null;
function customConfirm(message,{title=tr('Подтвердите действие'),okText=tr('Продолжить'),danger=false}={}){
  const modal=$('confirmModal');$('confirmTitle').textContent=title;$('confirmText').textContent=message;$('confirmOk').textContent=okText;$('confirmOk').classList.toggle('dangerButton',danger);$('confirmOk').classList.toggle('primaryButton',!danger);
  if(modal.open)modal.close();modal.showModal();requestAnimationFrame(()=>modal.classList.add('is-open'));
  return new Promise(resolve=>{confirmResolver=resolve});
}
function finishConfirm(value){const modal=$('confirmModal');modal.classList.remove('is-open');setTimeout(()=>{if(modal.open)modal.close()},160);const resolve=confirmResolver;confirmResolver=null;resolve?.(value)}

let importModeResolver=null;
function chooseImportMode(){
  const modal=$('importModeModal');
  if(modal.open)modal.close();
  modal.querySelector('input[value="replace"]').checked=true;
  modal.showModal();requestAnimationFrame(()=>modal.classList.add('is-open'));
  return new Promise(resolve=>{importModeResolver=resolve});
}
function finishImportMode(value){
  const modal=$('importModeModal');modal.classList.remove('is-open');setTimeout(()=>{if(modal.open)modal.close()},160);
  const resolve=importModeResolver;importModeResolver=null;resolve?.(value);
}
$('importModeForm').onsubmit=e=>{e.preventDefault();finishImportMode(new FormData(e.currentTarget).get('importMode')||'replace')};
$('cancelImportMode').onclick=$('closeImportMode').onclick=()=>finishImportMode(null);
$('importModeModal').addEventListener('cancel',e=>{e.preventDefault();finishImportMode(null)});
$('importModeModal').addEventListener('click',e=>{if(e.target===$('importModeModal'))finishImportMode(null)});

$('confirmCancel').onclick=()=>finishConfirm(false);$('confirmOk').onclick=()=>finishConfirm(true);$('confirmModal').addEventListener('cancel',e=>{e.preventDefault();finishConfirm(false)});$('confirmModal').addEventListener('click',e=>{if(e.target===$('confirmModal'))finishConfirm(false)});
if($('settingsVersion'))$('settingsVersion').textContent=`LeanTab ${APP_VERSION}`;
$('settingsBtn').onclick=()=>{if($('settingsModal').open)return;window.resetSettingsSearch?.();settingsSnapshot=structuredClone(config);settingsWallpaperInitialIds=new Set((config.settings.wallpapers||[]).map(x=>x.id));settingsDirty=false;$('saveSettingsBtn').classList.remove('save-attention');syncSettings();stopAnimation();$('settingsModal').showModal();requestAnimationFrame(()=>$('settingsModal').classList.add('is-open'));setTimeout(()=>$('closeSettings').focus(),80)};
function animateUnsaved(){const card=$('settingsForm'),btn=$('saveSettingsBtn');card.classList.remove('unsaved-shake');btn.classList.remove('save-attention');void card.offsetWidth;card.classList.add('unsaved-shake');btn.classList.add('save-attention');setTimeout(()=>card.classList.remove('unsaved-shake'),420)}
function finishCloseSettings(){window.resetSettingsSearch?.();$('settingsModal').classList.remove('is-open');setTimeout(()=>{if($('settingsModal').open)$('settingsModal').close();restartAnimation()},240)}
async function discardSettings(){if(settingsSnapshot){const restored=structuredClone(settingsSnapshot),restoredIds=new Set((restored.settings.wallpapers||[]).map(x=>x.id));await cleanupWallpaperAssets(restoredIds,(config.settings.wallpapers||[]).map(x=>x.id));config=restored;await hydrateAssets();setLanguage(config.settings.language);apply()}settingsSnapshot=null;settingsWallpaperInitialIds=new Set();settingsDirty=false;finishCloseSettings()}
async function requestCloseSettings(){if(!settingsDirty){discardSettings();return}animateUnsaved();if(await customConfirm(tr('Есть несохранённые изменения. Закрыть без сохранения?'),{okText:tr('Закрыть без сохранения')}))discardSettings()}
$('closeSettings').onclick=$('cancelSettings').onclick=requestCloseSettings;
$('settingsModal').addEventListener('click',e=>{if(e.target===$('settingsModal'))requestCloseSettings()});
$('settingsModal').addEventListener('cancel',e=>{e.preventDefault();requestCloseSettings()});
$('settingsForm').onsubmit=async e=>{e.preventDefault();readSettings();try{await persistAssetsFromConfig();if(!await save())return;await cleanupWallpaperAssets((config.settings.wallpapers||[]).map(x=>x.id),settingsWallpaperInitialIds);apply();settingsSnapshot=null;settingsWallpaperInitialIds=new Set();settingsDirty=false;$('saveSettingsBtn').classList.remove('save-attention');finishCloseSettings();toast(tr('Настройки сохранены'),'success')}catch(err){console.error('Settings save failed',err);toast(tr('Не удалось сохранить настройки'),'error')}};
document.querySelectorAll('[data-add-zone]').forEach(button=>button.onclick=()=>openTile(null,'link',button.dataset.addZone));
document.querySelector('#searchForm kbd')?.addEventListener('click',()=>{$('searchInput').focus();$('searchInput').select()});
document.querySelector('#searchForm kbd')?.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('searchInput').focus();$('searchInput').select()}});
document.querySelector('#searchForm kbd')?.setAttribute('tabindex','0');
document.querySelector('#searchForm kbd')?.setAttribute('role','button');
document.querySelector('#searchForm kbd')?.setAttribute('aria-label',tr('Перейти к строке поиска'));$('closeTileModal').onclick=$('cancelTile').onclick=closeTile;$('tileModal').addEventListener('click',e=>{if(e.target===$('tileModal'))closeTile()});$('tileModal').addEventListener('cancel',e=>{e.preventDefault();closeTile()});$('iconMode').onchange=toggleIconRows;['tileTitle','tileUrl','tileEmoji','tileColor','quickFolderName','quickFolderColor'].forEach(id=>$(id).addEventListener('input',previewTile));
$('tileIconFile').onchange=e=>{const f=e.target.files[0];if(!f)return;if(!IMAGE_TYPES.has(f.type)){toast(tr('Поддерживаются JPG, PNG, WEBP и GIF'),'error');e.target.value='';return}if(f.size>ICON_MAX_BYTES){toast(tr('Иконка слишком большая: максимум 3 МБ'),'error');e.target.value='';return}const r=new FileReader();r.onerror=()=>toast(tr('Не удалось прочитать изображение'),'error');r.onload=()=>{uploadedIcon=String(r.result||'');previewTile()};r.readAsDataURL(f)};
$('tileForm').onsubmit=async e=>{e.preventDefault();
  if(window.currentCreateMode==='folder'&&!editingId){
    const name=safeText($('quickFolderName').value,32); if(!name){toast(tr('Введите название папки'),'error');$('quickFolderName').focus();return}
    const before=structuredClone(config.folders);config.folders.push({id:uid(),name,zone:ZONES.includes($('quickFolderZone').value)?$('quickFolderZone').value:'bottom',color:validColor($('quickFolderColor').value)});
    if(!await save()){config.folders=before;renderLinks();return} renderLinks(); closeTile(); toast(tr('Папка создана'),'success'); return;
  }
  const title=safeText($('tileTitle').value,32), rawUrl=$('tileUrl').value.trim();if(!title||!rawUrl){toast(tr('Заполните название и адрес'),'error');return}
  let url;try{url=new URL(normalizeUrl(rawUrl));if(!['http:','https:'].includes(url.protocol))throw new Error()}catch{toast(tr('Введите корректный адрес сайта'),'error');$('tileUrl').focus();return}
  const item={id:editingId||uid(),title,url:url.href,folderId:$('tileFolder').value||'',zone:ZONES.includes($('tileZone').value)?$('tileZone').value:'bottom',iconMode:['favicon','emoji','initials','upload'].includes($('iconMode').value)?$('iconMode').value:'favicon',emoji:safeText($('tileEmoji').value,8),color:validColor($('tileColor').value)};
  const previous=editingId?config.links.find(x=>x.id===editingId):null;
  try{
    const oldIconData=previous?.iconMode==='upload'?(previous.iconData||await assetGet('icon:'+item.id).catch(()=>'')):'';
    if(item.iconMode==='upload'){item.iconData=uploadedIcon||oldIconData;if(!item.iconData){toast(tr('Выберите изображение для иконки'),'error');return}await assetSet('icon:'+item.id,item.iconData)}
    const before=structuredClone(config.links);if(editingId){const idx=config.links.findIndex(x=>x.id===editingId);if(idx<0)throw new Error('Link not found');config.links[idx]=item}else config.links.push(item);
    if(!await save()){
      config.links=before;
      if(item.iconMode==='upload'){if(oldIconData)await assetSet('icon:'+item.id,oldIconData).catch(()=>{});else await assetDelete('icon:'+item.id).catch(()=>{})}
      renderLinks();return
    }
    if(item.iconMode!=='upload'&&previous?.iconMode==='upload')await assetDelete('icon:'+item.id).catch(()=>{});
    renderLinks();closeTile();toast(tr('Ссылка сохранена'),'success')
  }catch(err){console.error('Tile save failed',err);toast(tr('Не удалось сохранить ссылку'),'error')}
};
$('deleteTile').onclick=async()=>{if(!editingId)return;const link=config.links.find(x=>x.id===editingId);if(link&&await customConfirm(tr('Удалить эту ссылку?'),{title:tr('Удаление ссылки'),okText:tr('Удалить'),danger:true})){const id=link.id,before=structuredClone(config.links);config.links=config.links.filter(x=>x.id!==id);if(!await save()){config.links=before;renderLinks();return}await assetDelete('icon:'+id).catch(()=>{});await closeTileAndWait();await animateTileRemoval(id);toast(tr('Ссылка удалена'),'success')}};
let wallpaperGalleryRenderToken=0;
async function createWallpaperThumbnail(data){
  if(!data)return '';
  return new Promise(resolve=>{const img=new Image();img.onload=()=>{try{const maxW=240,maxH=150,scale=Math.min(maxW/img.naturalWidth,maxH/img.naturalHeight,1),w=Math.max(1,Math.round(img.naturalWidth*scale)),h=Math.max(1,Math.round(img.naturalHeight*scale)),canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;canvas.getContext('2d',{alpha:false}).drawImage(img,0,0,w,h);resolve(canvas.toDataURL('image/jpeg',.72))}catch{resolve('')}};img.onerror=()=>resolve('');img.src=data});
}
async function getWallpaperThumbnail(id){
  const key='wallpaper-thumb:'+id,cached=await assetGet(key).catch(()=>'');if(cached)return cached;
  const full=await assetGet('wallpaper:'+id).catch(()=>'');const thumb=await createWallpaperThumbnail(full);if(thumb)await assetSet(key,thumb).catch(()=>{});return thumb;
}
async function renderWallpaperManager(){
  const box=$('wallpaperManager');if(!box)return;const list=config.settings.wallpapers||[],token=++wallpaperGalleryRenderToken;
  box.innerHTML=list.map((w,i)=>`<div class="wallpaperItem ${w.id===config.settings.wallpaperPrimary?'primary':''}" data-wallpaper-id="${w.id}"><button type="button" class="wallpaperPreview" title="Показать эту картинку"><img alt="" loading="lazy"><span>${i+1}</span></button><div class="wallpaperInfo"><strong>${w.name}</strong><small>${w.id===config.settings.wallpaperPrimary?'Основная картинка':'Картинка '+(i+1)}</small></div><div class="wallpaperActions"><button type="button" data-action="primary" title="Сделать основной" aria-label="Сделать основной">★</button><button type="button" data-action="up" title="Выше" aria-label="Переместить выше">↑</button><button type="button" data-action="down" title="Ниже" aria-label="Переместить ниже">↓</button><button type="button" data-action="delete" title="Удалить" aria-label="Удалить">×</button></div></div>`).join('')||'<p class="wallpaperEmpty">Добавьте до 20 изображений. Первая картинка станет основной.</p>';
  for(const w of list){const thumb=await getWallpaperThumbnail(w.id);if(token!==wallpaperGalleryRenderToken)return;if(!thumb)continue;const img=box.querySelector(`[data-wallpaper-id="${CSS.escape(w.id)}"] .wallpaperPreview img`);if(img)img.src=thumb}
}
$('wallpaperManager').onclick=async e=>{const row=e.target.closest('[data-wallpaper-id]');if(!row)return;const id=row.dataset.wallpaperId,list=config.settings.wallpapers;const i=list.findIndex(x=>x.id===id);if(i<0)return;const action=e.target.closest('[data-action]')?.dataset.action;if(!action){config.settings.wallpaperEnabled=true;await showWallpaper(id);settingsDirty=hasSettingsChanged();syncSettings();$('saveSettingsBtn').classList.toggle('save-attention',settingsDirty);return}if(action==='primary'){config.settings.wallpaperEnabled=true;config.settings.wallpaperPrimary=id;stopWallpaperRotation({resetDeadline:true});await showWallpaper(id)}if(action==='up'&&i>0)[list[i-1],list[i]]=[list[i],list[i-1]];if(action==='down'&&i<list.length-1)[list[i+1],list[i]]=[list[i],list[i+1]];if(action==='delete'){list.splice(i,1);await assetDelete('wallpaper-thumb:'+id).catch(()=>{});if(config.settings.wallpaperPrimary===id)config.settings.wallpaperPrimary=list[0]?.id||'';await showWallpaper(config.settings.wallpaperPrimary||list[0]?.id||'')}settingsDirty=hasSettingsChanged();syncSettings();$('saveSettingsBtn').classList.toggle('save-attention',settingsDirty)};
$('bgFile').onchange=async e=>{const files=[...e.target.files];if(!files.length)return;const room=WALLPAPER_MAX_COUNT-(config.settings.wallpapers?.length||0);if(room<=0){toast('Можно добавить максимум 20 картинок','error');e.target.value='';return}for(const f of files.slice(0,room)){if(f.size>BG_MAX_BYTES){toast(`${f.name}: максимум 15 МБ`,'error');continue}if(!IMAGE_TYPES.has(f.type)){toast(`${f.name}: неподдерживаемый формат`,'error');continue}const data=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=reject;r.readAsDataURL(f)}).catch(()=>null);if(!data)continue;const id=uid();await assetSet('wallpaper:'+id,data);const thumb=await createWallpaperThumbnail(data);if(thumb)await assetSet('wallpaper-thumb:'+id,thumb).catch(()=>{});config.settings.wallpapers.push({id,name:f.name});config.settings.wallpaperEnabled=true;if(!config.settings.wallpaperPrimary)config.settings.wallpaperPrimary=id;if(!activeWallpaperId)await showWallpaper(id)}config.settings.customBgEffects=false;config.settings.motionType='none';config.settings.overlayOpacity=0;settingsDirty=hasSettingsChanged();syncSettings();applyVisualSettings({restartFx:false,render:false});$('saveSettingsBtn').classList.toggle('save-attention',settingsDirty);e.target.value=''};
$('clearBg').onclick=async()=>{config.settings.wallpapers=[];config.settings.wallpaperPrimary='';config.settings.wallpaperEnabled=false;config.settings.customBg='';activeWallpaperId='';await assetDelete('background').catch(()=>{});settingsDirty=hasSettingsChanged();syncSettings();$('saveSettingsBtn').classList.toggle('save-attention',settingsDirty);applyVisualSettings({restartFx:false,render:false})};
$('exportBtn').onclick=async()=>{try{const payload={app:'LeanTab',version:APP_VERSION,formatVersion:3,exportedAt:new Date().toISOString(),config:structuredClone(config),profiles:structuredClone(profiles),wallpaperAssets:await collectWallpaperAssets()};if($('backupHistory').checked)payload.searchHistory=structuredClone(searchHistory);const a=document.createElement('a'),url=URL.createObjectURL(new Blob([JSON.stringify(payload,null,2)],{type:'application/json'}));a.href=url;a.download=`leantab-${APP_VERSION}-backup-${new Date().toISOString().slice(0,10)}.json`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);toast(tr('Резервная копия создана'),'success')}catch(err){console.error(err);toast(tr('Не удалось создать резервную копию'),'error')}};
$('importFile').onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onerror=()=>toast(tr('Не удалось прочитать файл'),'error');r.onload=async()=>{try{const payload=JSON.parse(String(r.result||''));const raw=payload.config||payload;const mode=await chooseImportMode();if(!mode)return;const imported=mergeConfig(raw);if(mode==='merge'){const seen=new Set(config.links.map(x=>x.url));config.links.push(...imported.links.filter(x=>!seen.has(x.url)));config.folders=[...config.folders,...imported.folders.filter(f=>!config.folders.some(x=>x.name===f.name))]}else if(mode==='appearance'){config.settings=imported.settings}else if(mode==='tiles'){config.links=imported.links;config.folders=imported.folders}else config=imported;if(Array.isArray(payload.searchHistory)){searchHistory=payload.searchHistory.map(x=>typeof x==='string'?{q:x,t:Date.now()}:x);pruneSearchHistory();await browser.storage.local.set({[SEARCH_HISTORY_KEY]:searchHistory})}if(payload.profiles&&typeof payload.profiles==='object'){profiles=payload.profiles;await browser.storage.local.set({[PROFILES_KEY]:profiles})}if((mode==='replace'||mode==='appearance')&&payload.wallpaperAssets)await restoreWallpaperAssets(payload.wallpaperAssets);await persistAssetsFromConfig();if(!await save())throw new Error('Storage save failed');settingsSnapshot=structuredClone(config);settingsDirty=false;syncSettings();apply();renderProfiles();toast(tr('Данные импортированы'),'success')}catch(err){console.error('Import failed',err);toast(tr('Не удалось импортировать файл'),'error')}finally{e.target.value=''}};r.readAsText(f)};
$('resetVisualBtn').onclick=async()=>{if(!await customConfirm(tr('Сбросить внешний вид, плитки и папки? История и профили останутся.'),{title:tr('Сброс внешнего вида'),okText:tr('Сбросить'),danger:true}))return;const before=config;const keepLanguage=config.settings.language;config=structuredClone(defaults);config.settings.language=keepLanguage;if(!await save()){config=before;return}await clearAssets().catch(err=>console.warn('Asset cleanup after reset failed',err));settingsSnapshot=structuredClone(config);syncSettings();apply();toast(tr('Внешний вид и плитки сброшены'),'success')};
$('resetBtn').onclick=async()=>{if(!await customConfirm(tr('Полностью удалить настройки, плитки, папки, историю, профили, фон и иконки LeanTab?'),{title:tr('Полная очистка'),okText:tr('Удалить всё'),danger:true}))return;try{await clearAssets();await browser.storage.local.clear();config=structuredClone(defaults);profiles={};searchHistory=[];await save();settingsSnapshot=structuredClone(config);syncSettings();apply();renderProfiles();toast(tr('LeanTab полностью очищен'),'success')}catch(err){console.error(err);toast(tr('Не удалось очистить данные'),'error')}};
window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{applyVisualSettings({restartFx:false,render:false});restartAnimation()},220)},{passive:true});
document.addEventListener('visibilitychange',()=>{
  document.body.classList.toggle('page-hidden',document.hidden);
  if(document.hidden){stopAnimation();clearTimeout(clockTimer);stopWallpaperRotation()}else{scheduleClock();restartAnimation();startWallpaperRotation()}
});
prefersReducedMotion.addEventListener?.('change',()=>apply());
window.addEventListener('keydown',e=>{if(e.key==='/'&&!document.querySelector('dialog[open]')){e.preventDefault();$('searchInput').focus()}});

const ENGAGEMENT_KEY='leanTabEngagementV1';
const FEEDBACK_URL='https://leantab.help/#contacts';
const TEN_MINUTES=10*60*1000;
const REVIEW_DELAY=7*24*60*60*1000;
const REVIEW_MIN_OPENS=15;
let engagementState=null;
let engagementTimer=0;

function reviewUrl(){return 'https://addons.mozilla.org/ru/firefox/addon/leantab/'}
function openExternal(url){try{window.open(url,'_blank','noopener,noreferrer')}catch{location.href=url}}
async function prepareEngagement(){
  try{
    const data=await browser.storage.local.get([ENGAGEMENT_KEY,STORAGE_KEY,LEGACY_KEY]);
    engagementState=data[ENGAGEMENT_KEY]||null;
    if(!engagementState){
      const existingUser=Boolean(data[STORAGE_KEY]||data[LEGACY_KEY]);
      engagementState={installedAt:Date.now(),feedbackShown:existingUser,reviewShown:false,opens:0};
    }
    engagementState.opens=(Number(engagementState.opens)||0)+1;
    await browser.storage.local.set({[ENGAGEMENT_KEY]:engagementState});
  }catch(err){console.warn('LeanTab engagement init failed',err);engagementState={installedAt:Date.now(),feedbackShown:true,reviewShown:true,opens:0}}
}
async function saveEngagement(){try{await browser.storage.local.set({[ENGAGEMENT_KEY]:engagementState})}catch(err){console.warn('LeanTab engagement save failed',err)}}
function hideEngagement(){
  clearTimeout(engagementTimer);
  const card=$('engagementCard');if(!card)return;
  card.classList.remove('show');setTimeout(()=>{if(!card.classList.contains('show'))card.hidden=true},240);
}
function showEngagement(kind){
  const card=$('engagementCard');if(!card||card.classList.contains('show'))return;
  const isFeedback=kind==='feedback';
  $('engagementTitle').textContent=tr(isFeedback?'Есть вопрос или идея?':'Нравится LeanTab?');
  $('engagementText').textContent=tr(isFeedback?'Если заметили ошибку, чего-то не хватает или хотите предложить улучшение — напишите нам. Мы обязательно прочитаем и учтём ваше сообщение.':'Если LeanTab стал частью вашей новой вкладки, короткая оценка на Firefox Add-ons очень поможет развитию проекта.');
  $('engagementPrimary').textContent=tr(isFeedback?'Написать нам':'Поставить оценку');
  $('engagementSecondary').textContent=tr(isFeedback?'Позже':'Есть проблема');
  card.dataset.kind=kind;card.hidden=false;requestAnimationFrame(()=>requestAnimationFrame(()=>card.classList.add('show')));
}
async function markEngagementShown(kind){
  if(!engagementState)return;
  if(kind==='feedback')engagementState.feedbackShown=true;else engagementState.reviewShown=true;
  await saveEngagement();
}
async function maybeScheduleEngagement(){
  if(!engagementState)return;
  const age=Date.now()-(Number(engagementState.installedAt)||Date.now());
  if(!engagementState.feedbackShown){
    const delay=Math.max(0,TEN_MINUTES-age);
    clearTimeout(engagementTimer);engagementTimer=setTimeout(async()=>{await markEngagementShown('feedback');showEngagement('feedback')},delay);
    return;
  }
  if(!engagementState.reviewShown&&age>=REVIEW_DELAY&&(Number(engagementState.opens)||0)>=REVIEW_MIN_OPENS){
    engagementTimer=setTimeout(async()=>{await markEngagementShown('review');showEngagement('review')},1400);
  }
}
$('engagementClose')?.addEventListener('click',hideEngagement);
$('engagementPrimary')?.addEventListener('click',()=>{const kind=$('engagementCard')?.dataset.kind;openExternal(kind==='review'?reviewUrl():FEEDBACK_URL);hideEngagement()});
$('engagementSecondary')?.addEventListener('click',()=>{const kind=$('engagementCard')?.dataset.kind;if(kind==='review')openExternal(FEEDBACK_URL);hideEngagement()});
$('feedbackBtn')?.addEventListener('click',()=>openExternal(FEEDBACK_URL));
$('rateBtn')?.addEventListener('click',()=>openExternal(reviewUrl()));

(async()=>{try{await prepareEngagement();await load();setLanguage(config.settings.language,{translateGenerated:false});buildSettingsUI();bindLiveSettings();setupDropZones();await loadProfiles();await loadSearchHistory();apply();syncSettings();requestAnimationFrame(()=>requestAnimationFrame(refreshFirefoxRangeTheme));await maybeScheduleEngagement()}catch(err){console.error('LeanTab startup failed',err);try{syncSettings();apply()}catch(renderErr){console.error('LeanTab fallback render failed',renderErr)}setTimeout(()=>toast(tr('LeanTab не удалось полностью запустить. Ваши сохранённые данные не удалены.'),'error'),150)}finally{requestAnimationFrame(()=>requestAnimationFrame(()=>{document.body.classList.add('ready');document.body.classList.remove('booting')}))}})();

// Emergency recovery: Ctrl+0 always restores LeanTab to 100%.
// Capture phase is used so the shortcut works even when an input or dialog is focused.
window.addEventListener('keydown',async event=>{
  const isReset=(event.ctrlKey||event.metaKey) && (event.code==='Digit0'||event.code==='Numpad0'||event.key==='0');
  if(!isReset)return;
  event.preventDefault();
  event.stopImmediatePropagation();
  if(!config?.settings)return;
  config.settings.uiScale=100;
  document.documentElement.style.setProperty('--ui-scale','1');
  document.documentElement.style.setProperty('--ui-scale-effective','1');
  for(const element of [document.documentElement,document.body,document.querySelector('.app')]){
    if(!element)continue;
    element.style.removeProperty('zoom');
    element.style.removeProperty('scale');
    element.style.removeProperty('transform');
    element.style.removeProperty('transform-origin');
  }
  const scaleInput=document.getElementById('uiScale');
  if(scaleInput)scaleInput.value='100';
  const output=document.getElementById('uiScaleValue');
  if(output)output.value='100%';
  apply();
  await save();
  if(typeof toast==='function')toast(tr('Масштаб LeanTab восстановлен: 100%'),'success');
},true);
