function createTileElement(link,i){
  const a=document.createElement('a');a.className='tile';a.dataset.linkId=link.id;a.href=safeUrl(link.url);a.draggable=!config.settings.lockTiles;a.style.setProperty('--accent',validColor(link.color));a.style.animationDelay=`${Math.min(i*28,260)}ms`;a.setAttribute('aria-label',link.title);
  const title=document.createElement('span');title.className='tileTitle';title.textContent=link.title;
  const edit=document.createElement('button');edit.className='tileEdit';edit.type='button';edit.title=tr('Изменить');edit.setAttribute('aria-label',currentLanguage==='ru'?`Изменить ${link.title}`:`Edit ${link.title}`);edit.textContent='✎';
  a.append(makeIcon(link),title,edit);
  if(!config.settings.lockTiles){a.addEventListener('dragstart',e=>{draggedTile={id:link.id,type:'link'};e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('application/x-leantab-tile',JSON.stringify(draggedTile));e.dataTransfer.setData('text/plain',link.id);requestAnimationFrame(()=>a.classList.add('dragging'));document.body.classList.add('sorting-tiles')});a.addEventListener('dragend',()=>{draggedTile=null;a.classList.remove('dragging');document.body.classList.remove('sorting-tiles');clearDropIndicators()})}
  a.addEventListener('click',e=>{
    if(document.body.classList.contains('sorting-tiles')){e.preventDefault();return}
    if(e.defaultPrevented||e.button!==0||e.metaKey||e.ctrlKey||e.shiftKey||e.altKey)return;
    if(config.settings.tileClickEffect==='none')return;
    e.preventDefault();
    if(a.classList.contains('click-feedback'))return;
    a.classList.add('click-feedback');
    const href=a.href;
    const delay=config.settings.tileClickEffect==='bounce'?210:config.settings.tileClickEffect==='pulse'?190:155;
    setTimeout(()=>{location.href=href},delay);
  });
  a.addEventListener('contextmenu',e=>{e.preventDefault();showTileContextMenu(link,e.clientX,e.clientY)});
  edit.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openTile(link.id)});
  return a;
}
function createFolderElement(folder,i){
  const b=document.createElement('button');b.type='button';b.className='tile folderTile';b.dataset.folderId=folder.id;b.draggable=!config.settings.lockTiles;b.style.setProperty('--accent',validColor(folder.color));b.style.animationDelay=`${Math.min(i*28,260)}ms`;b.setAttribute('aria-label',folder.name);
  const icon=document.createElement('span');icon.className='tileIcon folderIcon';icon.setAttribute('aria-hidden','true');
  const glyph=document.createElement('span');glyph.className='folderGlyph';icon.append(glyph);
  const title=document.createElement('span');title.className='tileTitle';title.textContent=folder.name;
  const count=document.createElement('small');count.className='folderCount';count.textContent=String(config.links.filter(x=>x.folderId===folder.id).length);
  const edit=document.createElement('button');edit.className='tileEdit folderEdit';edit.type='button';edit.title=tr('Изменить');edit.setAttribute('aria-label',currentLanguage==='ru'?`Изменить папку ${folder.name}`:`Edit folder ${folder.name}`);edit.textContent='✎';
  b.append(icon,title,count,edit);
  if(!config.settings.lockTiles){b.addEventListener('dragstart',e=>{draggedTile={id:folder.id,type:'folder'};e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('application/x-leantab-tile',JSON.stringify(draggedTile));e.dataTransfer.setData('text/plain',folder.id);requestAnimationFrame(()=>b.classList.add('dragging'));document.body.classList.add('sorting-tiles')});b.addEventListener('dragend',()=>{draggedTile=null;b.classList.remove('dragging');document.body.classList.remove('sorting-tiles');clearDropIndicators()})}
  b.addEventListener('click',e=>{if(document.body.classList.contains('sorting-tiles')||e.target.closest('.tileEdit'))return;openFolderView(folder.id)});
  edit.draggable=false;edit.addEventListener('dragstart',e=>e.preventDefault());edit.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openFolderEditor(folder.id)});
  b.oncontextmenu=e=>{e.preventDefault();showFolderContextMenu(folder,e.clientX,e.clientY)};
  return b;
}
function tileMotionKey(tile){
  const kind=tile.dataset.folderId?'folder':'link';
  const id=tile.dataset.folderId||tile.dataset.linkId||'';
  const host=tile.closest('#folderItems')?'folder-view':tile.parentElement?.id||'zone';
  return `${kind}:${id}:${host}`;
}
function snapshotTileLayout(excludeSelector=''){
  const map=new Map();
  document.querySelectorAll('.links>.tile,.folderItems>.tile').forEach(tile=>{
    if(excludeSelector&&tile.matches(excludeSelector))return;
    const key=tileMotionKey(tile),list=map.get(key)||[];
    list.push(tile.getBoundingClientRect());map.set(key,list);
  });
  return map;
}
async function animateTileRemoval(linkId, kind='link'){
  const attr=kind==='folder'?'folder-id':'link-id';
  const selector=`.tile[data-${attr}="${CSS.escape(String(linkId))}"]`;
  const targets=[...document.querySelectorAll(selector)];
  if(prefersReducedMotion.matches){renderLinks();return}
  const before=snapshotTileLayout(selector);
  if(targets.length){
    await Promise.all(targets.map(tile=>tile.animate([
      {opacity:1,transform:'scale(1)',filter:'blur(0)'},
      {opacity:.86,transform:'scale(.975)',offset:.38},
      {opacity:0,transform:'scale(.9)',filter:'blur(1.2px)'}
    ],{duration:300,easing:'cubic-bezier(.4,0,.2,1)',fill:'forwards'}).finished.catch(()=>{})));
  }
  renderLinks();
  await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));
  const used=new Map(),moves=[];
  document.querySelectorAll('.links>.tile,.folderItems>.tile').forEach(tile=>{
    const key=tileMotionKey(tile),index=used.get(key)||0;used.set(key,index+1);
    const oldRect=before.get(key)?.[index];if(!oldRect)return;
    const now=tile.getBoundingClientRect(),dx=oldRect.left-now.left,dy=oldRect.top-now.top;
    if(Math.abs(dx)<.5&&Math.abs(dy)<.5)return;
    moves.push(tile.animate([
      {transform:`translate(${dx}px,${dy}px)`,offset:0},
      {transform:'translate(0,0)',offset:1}
    ],{duration:380,easing:'cubic-bezier(.22,.8,.2,1)'}).finished.catch(()=>{}));
  });
  await Promise.all(moves);
}
function getZoneMixedItems(zoneName){
  return [
    ...config.folders.filter(folder=>folder.zone===zoneName).map(folder=>({type:'folder',id:folder.id,item:folder})),
    ...config.links.filter(link=>link.zone===zoneName&&!(link.folderId&&config.folders.some(folder=>folder.id===link.folderId))).map(link=>({type:'link',id:link.id,item:link}))
  ].sort((a,b)=>(Number(a.item.order)||0)-(Number(b.item.order)||0));
}
function normalizeZoneOrders(zoneName){getZoneMixedItems(zoneName).forEach((entry,index)=>entry.item.order=index)}
function getNextZoneOrder(zoneName){const items=getZoneMixedItems(zoneName);return items.length?Math.max(...items.map(entry=>Number(entry.item.order)||0))+1:0}
function renderLinks(){
  for(const z of ZONES){
    const host=$(`links${z[0].toUpperCase()+z.slice(1)}`);host.replaceChildren();
    getZoneMixedItems(z).forEach((entry,index)=>host.append(entry.type==='folder'?createFolderElement(entry.item,index):createTileElement(entry.item,index)));
  }
  renderFolderManager(); updateFolderSelect();
  refreshOpenFolderView();
}
function clearDropIndicators(){
  document.querySelectorAll('.linkZone').forEach(z=>z.classList.remove('dragOver'));
  document.querySelectorAll('.tile.drop-before,.tile.drop-after').forEach(t=>t.classList.remove('drop-before','drop-after'));
}
function getDropPosition(zone,e){
  const tiles=[...zone.querySelectorAll('.tile:not(.dragging)')];
  const vertical=zone.dataset.zone==='left'||zone.dataset.zone==='right';
  for(let i=0;i<tiles.length;i++){
    const r=tiles[i].getBoundingClientRect();
    const pointer=vertical?e.clientY:e.clientX;
    const midpoint=vertical?r.top+r.height/2:r.left+r.width/2;
    if(pointer<midpoint)return {index:i,target:tiles[i],before:true};
  }
  return {index:tiles.length,target:tiles.at(-1)||null,before:false};
}
async function moveMixedTileTo(ref,zoneName,zoneIndex){
  if(!ref?.id||!['link','folder'].includes(ref.type))return false;
  const collection=ref.type==='folder'?config.folders:config.links;
  const item=collection.find(x=>x.id===ref.id);if(!item)return false;
  const beforeLinks=structuredClone(config.links),beforeFolders=structuredClone(config.folders);
  const oldZone=item.zone;
  item.zone=zoneName;
  const targetItems=getZoneMixedItems(zoneName).filter(entry=>!(entry.type===ref.type&&entry.id===ref.id));
  const safeIndex=Math.max(0,Math.min(Number(zoneIndex)||0,targetItems.length));
  targetItems.splice(safeIndex,0,{type:ref.type,id:ref.id,item});
  targetItems.forEach((entry,index)=>entry.item.order=index);
  if(oldZone!==zoneName)normalizeZoneOrders(oldZone);
  if(!await save()){config.links=beforeLinks;config.folders=beforeFolders;renderLinks();return false}
  renderLinks();return true;
}
function setupDropZones(){
  document.querySelectorAll('.linkZone').forEach(zone=>{
    zone.addEventListener('dragover',e=>{
      e.preventDefault();
      e.dataTransfer.dropEffect='move';
      clearDropIndicators();
      zone.classList.add('dragOver');
      const p=getDropPosition(zone,e);
      if(p.target)p.target.classList.add(p.before?'drop-before':'drop-after');
    });
    zone.addEventListener('dragleave',e=>{if(!zone.contains(e.relatedTarget)){zone.classList.remove('dragOver');document.querySelectorAll('.tile.drop-before,.tile.drop-after').forEach(t=>t.classList.remove('drop-before','drop-after'))}});
    zone.addEventListener('drop',async e=>{
      e.preventDefault();
      let ref=draggedTile;
      if(!ref){try{ref=JSON.parse(e.dataTransfer.getData('application/x-leantab-tile')||'null')}catch{ref=null}}
      const p=getDropPosition(zone,e);
      clearDropIndicators();
      if(ref)await moveMixedTileTo(ref,zone.dataset.zone,p.index);
    });
  });
}
function openTile(id=null,mode='link',preferredZone='bottom'){
  editingId=id; uploadedIcon=''; window.currentCreateMode=id?'link':mode;
  $('tileIconFile').value='';
  const l=id?config.links.find(x=>x.id===id):{title:'',url:'',zone:ZONES.includes(preferredZone)?preferredZone:'bottom',iconMode:'favicon',emoji:'',color:'#8b5cf6'};
  $('tileTitle').value=l.title; $('tileUrl').value=l.url; $('tileZone').value=l.zone;
  $('iconMode').value=l.iconMode||'favicon'; $('tileEmoji').value=l.emoji||''; $('tileColor').value=l.color||'#8b5cf6';
  $('quickFolderName').value=''; $('quickFolderZone').value=ZONES.includes(preferredZone)?preferredZone:'bottom'; $('quickFolderColor').value='#8b5cf6';
  updateFolderSelect(); $('tileFolder').value=l.folderId||'';
  toggleIconRows(); previewTile(); setCreateMode(window.currentCreateMode);
  $('tileModal').showModal(); requestAnimationFrame(()=>$('tileModal').classList.add('is-open'));
  setTimeout(()=>$(window.currentCreateMode==='folder'?'quickFolderName':'tileTitle')?.focus(),80);
}

function setCreateMode(mode){
  window.currentCreateMode=mode==='folder'?'folder':'link';
  const isFolder=window.currentCreateMode==='folder';
  $('linkCreateFields')?.classList.toggle('hidden',isFolder);
  $('folderCreateFields')?.classList.toggle('hidden',!isFolder);
  $('tilePreview')?.classList.remove('hidden');
  $('deleteTile')?.classList.toggle('hidden',!editingId);

  // Native HTML form validation also validates hidden `required` fields.
  // When switching to folder mode, tileTitle/tileUrl are hidden, so Chrome
  // blocked submit before our onsubmit handler could create the folder.
  // Keep `required` only on the fields that belong to the active mode.
  $('tileTitle').required=!isFolder;
  $('tileUrl').required=!isFolder;
  $('quickFolderName').required=isFolder;

  if($('tileModalTitle'))$('tileModalTitle').textContent=editingId?tr('Изменить сайт'):(isFolder?tr('Создать папку'):tr('Добавить сайт'));
  document.querySelectorAll('[data-create-mode]').forEach(b=>{const active=b.dataset.createMode===window.currentCreateMode;b.classList.toggle('active',active);b.setAttribute('aria-selected',String(active));b.disabled=!!editingId});
  previewTile();
  setTimeout(()=>$(isFolder?'quickFolderName':'tileTitle')?.focus(),50);
}
document.querySelectorAll('#createModeSwitch [data-create-mode]').forEach(button=>button.addEventListener('click',()=>{if(!editingId)setCreateMode(button.dataset.createMode)}));

function closeTile(){
  const modal=$('tileModal');
  modal.classList.remove('is-open');
  setTimeout(()=>{if(modal.open)modal.close();editingId=null;uploadedIcon='';$('tileIconFile').value=''},180);
}
function closeTileAndWait(){
  const modal=$('tileModal');
  if(!modal.open)return Promise.resolve();
  modal.classList.remove('is-open');
  return new Promise(resolve=>setTimeout(()=>{if(modal.open)modal.close();editingId=null;uploadedIcon='';$('tileIconFile').value='';resolve()},190));
}
function toggleIconRows(){$('emojiRow').classList.toggle('hidden',$('iconMode').value!=='emoji');$('uploadRow').classList.toggle('hidden',$('iconMode').value!=='upload');previewTile()}
function previewTile(){
  const preview=$('tilePreview');if(!preview)return;
  if(window.currentCreateMode==='folder'&&!editingId){
    const folder={name:safeText($('quickFolderName').value,32)||tr('Новая папка'),color:validColor($('quickFolderColor').value)};
    const tile=document.createElement('div');tile.className='tile folderTile previewOnly';tile.style.setProperty('--accent',folder.color);
    const icon=document.createElement('span');icon.className='tileIcon folderIcon';icon.setAttribute('aria-hidden','true');
    const glyph=document.createElement('span');glyph.className='folderGlyph';icon.append(glyph);
    const title=document.createElement('span');title.className='tileTitle';title.textContent=folder.name;
    const count=document.createElement('small');count.className='folderCount';count.textContent='0';
    tile.append(icon,title,count);preview.replaceChildren(tile);return;
  }
  const l={title:safeText($('tileTitle').value,32)||tr('Название'),url:safeUrl($('tileUrl').value||'example.com'),iconMode:$('iconMode').value,emoji:safeText($('tileEmoji').value,8),iconData:uploadedIcon,color:validColor($('tileColor').value)};
  const tile=document.createElement('div');tile.className='tile previewOnly';tile.style.setProperty('--accent',l.color);
  const title=document.createElement('span');title.className='tileTitle';title.textContent=l.title;tile.append(makeIcon(l),title);preview.replaceChildren(tile)
}

const customSelectRegistry=new WeakMap();
function refreshCustomSelect(select){
  const state=customSelectRegistry.get(select);if(!state)return;
  const option=select.options[select.selectedIndex]||select.options[0];
  state.buttonText.textContent=option?.textContent||tr('Выберите значение');
  state.button.disabled=select.disabled;
}
function closeCustomSelects(except=null){
  document.querySelectorAll('.customSelect.open').forEach(wrapper=>{if(wrapper!==except){wrapper.classList.remove('open');wrapper.querySelector('.customSelectButton')?.setAttribute('aria-expanded','false')}});
}
function rebuildCustomSelect(select,state){
  state.list.replaceChildren();
  [...select.options].forEach((option,index)=>{
    const item=document.createElement('button');item.type='button';item.className='customSelectOption';item.setAttribute('role','option');item.dataset.value=option.value;item.disabled=option.disabled;
    item.setAttribute('aria-selected',String(index===select.selectedIndex));item.textContent=option.textContent;
    item.onclick=()=>{select.value=option.value;select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));refreshCustomSelect(select);state.wrapper.classList.remove('open');state.button.setAttribute('aria-expanded','false');state.button.focus()};
    state.list.append(item);
  });
}
function enhanceSelect(select){
  if(!select||customSelectRegistry.has(select))return;
  const wrapper=document.createElement('div');wrapper.className='customSelect';wrapper.dataset.searchIgnore='true';
  const button=document.createElement('button');button.type='button';button.className='customSelectButton';button.setAttribute('aria-haspopup','listbox');button.setAttribute('aria-expanded','false');
  const buttonText=document.createElement('span');const arrow=document.createElement('i');arrow.setAttribute('aria-hidden','true');button.append(buttonText,arrow);
  const list=document.createElement('div');list.className='customSelectList';list.setAttribute('role','listbox');list.tabIndex=-1;wrapper.append(button,list);select.after(wrapper);
  select.classList.add('nativeSelectHidden');select.tabIndex=-1;select.setAttribute('aria-hidden','true');
  const state={wrapper,button,buttonText,list};customSelectRegistry.set(select,state);refreshCustomSelect(select);
  button.onclick=e=>{e.preventDefault();e.stopPropagation();const opening=!wrapper.classList.contains('open');closeCustomSelects(wrapper);if(opening){rebuildCustomSelect(select,state);wrapper.classList.add('open');button.setAttribute('aria-expanded','true');const chosen=list.querySelector('[aria-selected="true"]');chosen?.scrollIntoView({block:'nearest'})}else{wrapper.classList.remove('open');button.setAttribute('aria-expanded','false')}};
  button.onkeydown=e=>{if(['ArrowDown','ArrowUp','Home','End'].includes(e.key)){e.preventDefault();if(!wrapper.classList.contains('open'))button.click();const items=[...list.querySelectorAll('.customSelectOption:not(:disabled)')];if(!items.length)return;let i=items.indexOf(document.activeElement);if(e.key==='Home')i=0;else if(e.key==='End')i=items.length-1;else i=Math.max(0,Math.min(items.length-1,i+(e.key==='ArrowUp'?-1:1)));items[i].focus()}else if(e.key==='Escape'){wrapper.classList.remove('open');button.setAttribute('aria-expanded','false')}};
  list.addEventListener('keydown',e=>{const items=[...list.querySelectorAll('.customSelectOption:not(:disabled)')],i=items.indexOf(document.activeElement);if(e.key==='Escape'){e.preventDefault();wrapper.classList.remove('open');button.setAttribute('aria-expanded','false');button.focus()}else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();items[Math.max(0,Math.min(items.length-1,i+(e.key==='ArrowUp'?-1:1)))]?.focus()}else if(e.key==='Home'||e.key==='End'){e.preventDefault();items[e.key==='Home'?0:items.length-1]?.focus()}});
  select.addEventListener('change',()=>refreshCustomSelect(select));
}
function initCustomSelects(root=document){root.querySelectorAll('select').forEach(enhanceSelect)}
function refreshAllCustomSelects(){document.querySelectorAll('select').forEach(select=>{enhanceSelect(select);refreshCustomSelect(select)})}
window.refreshAllCustomSelects=refreshAllCustomSelects;
document.addEventListener('click',e=>{if(!e.target.closest('.customSelect'))closeCustomSelects()});

function buildSettingsUI(){
  const themePicker=$('themePicker'),motionType=$('motionType'),zoneSettings=$('zoneSettings');
  if(!themePicker||!motionType||!zoneSettings)throw new Error('Settings UI containers are missing');
  themePicker.replaceChildren(...Object.entries(THEMES).map(([k,t])=>{const button=document.createElement('button');button.type='button';button.dataset.theme=k;const preview=document.createElement('i');preview.style.background=t.preview;const label=document.createElement('span');label.textContent=t.label;button.append(preview,label);return button}));
  motionType.replaceChildren(...MOTIONS.map(([v,l])=>{const option=document.createElement('option');option.value=v;option.textContent=tr(l);return option}));
  const labels={top:tr('Сверху'),bottom:tr('Снизу'),left:tr('Слева'),right:tr('Справа')};
  const makeRangeLabel=(z,suffix,title,min,max,help)=>{const label=document.createElement('label');label.className='rangeLabel';const span=document.createElement('span');span.append(document.createTextNode(`${title} `));const output=document.createElement('output');output.id=`${z}${suffix}Value`;span.append(output);const input=document.createElement('input');input.id=`${z}${suffix}`;input.type='range';input.min=String(min);input.max=String(max);input.step='1';const small=document.createElement('small');small.textContent=help;label.append(span,input,small);return label};
  zoneSettings.replaceChildren(...ZONES.map(z=>{const horizontal=z==='top'||z==='bottom';const sizeLabel=horizontal?tr('Ширина ряда'):tr('Ширина области');const details=document.createElement('details');const summary=document.createElement('summary');summary.textContent=labels[z];const grid=document.createElement('div');grid.className='zoneGrid';grid.append(makeRangeLabel(z,'Inset',tr('Отступ от края'),0,180,tr('Расстояние зоны от соответствующего края экрана')),makeRangeLabel(z,'Shift',tr('Сдвиг вдоль края'),-320,320,tr('Перемещает всю зону вдоль края; 0 — по центру')),makeRangeLabel(z,'Gap',tr('Интервал плиток'),0,40,tr('Расстояние между плитками и кнопкой добавления')),makeRangeLabel(z,'Max',sizeLabel,20,horizontal?96:40,horizontal?tr('Ширина верхней или нижней зоны — до 96% экрана'):tr('Доступное пространство боковой зоны; ограничено безопасными 40% экрана')));details.append(summary,grid);return details}));
  const nav=$('settingsNav'), body=$('settingsBody');
  const sectionNames=[tr('Язык'),tr('Внешний вид'),tr('Анимация'),tr('Центр'),tr('Плитки'),tr('Зоны'),tr('Данные')];
  document.querySelectorAll('.settingsBody>.settingsSection').forEach((section,index)=>{section.dataset.section=String(index);section.id=`settings-section-${index}`});
  nav.replaceChildren(...sectionNames.map((name,index)=>{const button=document.createElement('button');button.type='button';button.dataset.sectionTarget=String(index);if(index===0)button.classList.add('active');button.textContent=name;return button}));
  const activateSection=index=>{window.activeSettingsSection=index;document.querySelectorAll('.settingsBody>.settingsSection').forEach((section,i)=>section.classList.toggle('active',i===index));nav.querySelectorAll('button').forEach((button,i)=>button.classList.toggle('active',i===index));document.body.classList.toggle('zone-settings-preview',index===5);body.scrollTop=0}; window.activateSettingsSection=activateSection; activateSection(0); nav.onclick=e=>{const button=e.target.closest('[data-section-target]');if(button)activateSection(Number(button.dataset.sectionTarget))};
  initCustomSelects();
  themePicker.onclick=e=>{const b=e.target.closest('[data-theme]');if(!b)return;config.settings.theme=b.dataset.theme;config.settings.wallpaperEnabled=false;config.settings.customBg='';activeWallpaperId='';stopWallpaperRotation({resetDeadline:false});settingsDirty=hasSettingsChanged();syncSettings();apply();$('saveSettingsBtn')?.classList.toggle('save-attention',settingsDirty)};
}
function syncSettings(){
  const s=config.settings;
  document.querySelectorAll('[data-theme]').forEach(b=>b.classList.toggle('active',!s.wallpaperEnabled&&b.dataset.theme===s.theme));
  const fields=['languageSelect','wallpaperMode','wallpaperInterval','customBgEffects','overlayOpacity','saturation','backgroundFit','backgroundPositionX','glassEffect','fontFamily','clockFont','motionType','motionSpeed','motionIntensity','motionScale','particleCount','clockSize','dateSize','dateOpacity','clockWeight','clockSpacing','clockGlow','userName','showGreeting','showDate','use24h','showSeconds','showSearch','searchWidth','searchHeight','tileScale','tileRadius','tileOpacity','tileAccentIntensity','tileHoverEffect','tileClickEffect','tileEffectIntensity','showLabels','showZones','uiScale','lockTiles','hideAddButtons','searchHistoryEnabled','searchHistoryLimit','searchHistoryDays','privateSearch'];
  for(const f of fields){const el=$(f);if(!el)continue;const key=f==='languageSelect'?'language':f;el[el.type==='checkbox'?'checked':'value']=s[key]}
  const units={overlayOpacity:'%',saturation:'%',backgroundPositionX:'%',motionSpeed:'',motionIntensity:'%',motionScale:'%',particleCount:'',clockSize:' px',dateSize:' px',dateOpacity:'%',clockWeight:'',clockSpacing:'',clockGlow:'%',searchWidth:' px',searchHeight:' px',tileScale:'%',tileRadius:' px',tileOpacity:'%',tileAccentIntensity:'%',tileEffectIntensity:'%',uiScale:'%'};
  const datePresets=['#ffffff','#d1d5db','#94a3b8','#a78bfa','#60a5fa','#34d399','#fbbf24','#fb7185'];
  const currentDateColor=validColor(s.dateColor||'#ffffff').toLowerCase();
  if($('dateColor'))$('dateColor').value=currentDateColor;
  if($('dateColorPreset'))$('dateColorPreset').value=datePresets.includes(currentDateColor)?currentDateColor:'custom';
  $('dateCustomColorRow')?.classList.toggle('hidden',$('dateColorPreset')?.value!=='custom');
  if($('dateColorSwatch'))$('dateColorSwatch').style.background=currentDateColor;
  for(const [f,u] of Object.entries(units)){const o=$(f+'Value');if(o)o.value=s[f]+u}
  for(const z of ZONES)for(const p of ['Inset','Shift','Gap','Max']){const key=p.toLowerCase(),el=$(`${z}${p}`);el.value=s.zones[z][key];$(`${z}${p}Value`).value=s.zones[z][key]+(p==='Max'?'%':' px')}
  if($('bgFileName'))$('bgFileName').textContent=s.wallpapers?.length?`${s.wallpapers.length} ${tr('Картинка')}`:tr('Картинки не добавлены');
  $('wallpaperIntervalRow')?.classList.toggle('hidden',s.wallpaperMode!=='timer');
  renderWallpaperManager?.();
  if($('clearBg'))$('clearBg').classList.toggle('hidden',!s.customBg);
  fillAllRanges();
  refreshAllCustomSelects();
}
function readSettings(){
  const s=config.settings,fields=['wallpaperInterval','uiScale','searchHistoryLimit','searchHistoryDays','overlayOpacity','saturation','backgroundPositionX','motionSpeed','motionIntensity','motionScale','particleCount','clockSize','dateSize','dateOpacity','clockWeight','clockSpacing','clockGlow','searchWidth','searchHeight','tileScale','tileRadius','tileOpacity','tileAccentIntensity','tileEffectIntensity'];for(const f of fields)s[f]=Number($(f).value);
  for(const f of ['customBgEffects','glassEffect','showGreeting','showDate','use24h','showSeconds','showSearch','showLabels','showZones','lockTiles','hideAddButtons','privateSearch'])s[f]=$(f).checked; s.searchHistoryEnabled=$('searchHistoryEnabled').value==='true';
  s.language=$('languageSelect')?.value==='ru'?'ru':'en'; s.wallpaperMode=$('wallpaperMode')?.value||'static'; for(const f of ['backgroundFit','motionType','clockFont','userName','tileHoverEffect','tileClickEffect'])s[f]=$(f).value; const datePreset=$('dateColorPreset')?.value||'#ffffff'; s.dateColor=validColor(datePreset==='custom'?$('dateColor').value:datePreset);
  for(const z of ZONES)for(const p of ['Inset','Shift','Gap','Max'])s.zones[z][p.toLowerCase()]=Number($(`${z}${p}`).value);
  normalizeNumericSettings(s);
}
function hasSettingsChanged(){
  if(!settingsSnapshot)return false;
  const current=config;config=settingsSnapshot;const snapshotSafe=storageSafeConfig();config=current;
  return JSON.stringify(storageSafeConfig())!==JSON.stringify(snapshotSafe) || config.settings.customBg!==settingsSnapshot.settings.customBg;
}
function bindLiveSettings(){
  $('settingsForm').addEventListener('input',e=>{
    if(e.target.type==='file')return;
    const previousMotion=`${config.settings.motionType}|${config.settings.particleCount}`;
    readSettings();
    if(e.target.id==='languageSelect')setLanguage(config.settings.language);
    settingsDirty=hasSettingsChanged();
    $('saveSettingsBtn').classList.toggle('save-attention',settingsDirty);
    updateSettingOutput(e.target.id);
    if(e.target.id==='wallpaperMode')$('wallpaperIntervalRow')?.classList.toggle('hidden',config.settings.wallpaperMode!=='timer');
    if(e.target.id==='dateColorPreset')$('dateCustomColorRow')?.classList.toggle('hidden',e.target.value!=='custom');
    if(e.target.id==='dateColor'&&$('dateColorSwatch'))$('dateColorSwatch').style.background=e.target.value;
    scheduleLiveApply();
    const nextMotion=`${config.settings.motionType}|${config.settings.particleCount}`;
    if(previousMotion!==nextMotion)scheduleAnimationRestart();
  });
}
$('dateColorButton')?.addEventListener('click',()=>$('dateColor')?.click());
function updateSettingOutput(id){
  const units={overlayOpacity:'%',saturation:'%',backgroundPositionX:'%',motionSpeed:'',motionIntensity:'%',motionScale:'%',particleCount:'',clockSize:' px',dateSize:' px',dateOpacity:'%',clockWeight:'',clockSpacing:'',clockGlow:'%',searchWidth:' px',searchHeight:' px',tileScale:'%',tileRadius:' px',tileOpacity:'%',tileAccentIntensity:'%',tileEffectIntensity:'%',uiScale:'%'};
  const output=$(id+'Value');
  if(output)output.value=$(id).value+(units[id]||'');
  const m=id.match(/^(top|bottom|left|right)(Inset|Shift|Gap|Max)$/);
  if(m){const out=$(id+'Value');if(out)out.value=$(id).value+(m[2]==='Max'?'%':' px')}
  fillRange($(id));
}
function fillRange(el){
  if(!el||el.type!=='range')return;
  const min=Number(el.min)||0,max=Number(el.max)||100,val=Number(el.value)||0;
  const pct=max>min?((val-min)/(max-min))*100:0;
  el.style.setProperty('--range-progress',`${pct}%`);
}
function fillAllRanges(){document.querySelectorAll('input[type=range]').forEach(fillRange)}
function refreshFirefoxRangeTheme(){
  if(typeof browser==='undefined')return;
  const ranges=[...document.querySelectorAll('input[type=range]')];
  for(const el of ranges){const progress=el.style.getPropertyValue('--range-progress');el.style.removeProperty('--range-progress');void el.offsetWidth;if(progress)el.style.setProperty('--range-progress',progress)}
}

function toast(msg,type='info'){const t=$('toast');t.textContent=msg;t.dataset.type=type;t.classList.add('show');clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),2200)}

function resizeCanvas(){
  const c=$('fxCanvas'),dpr=LOW_POWER_DEVICE?1:Math.min(devicePixelRatio||1,1.5);
  const w=Math.max(1,Math.floor(innerWidth*dpr)),h=Math.max(1,Math.floor(innerHeight*dpr));
  if(c.width!==w)c.width=w;if(c.height!==h)c.height=h;
  c.style.width=innerWidth+'px';c.style.height=innerHeight+'px';
  c.getContext('2d').setTransform(dpr,0,0,dpr,0,0);
}
function stopAnimation(){cancelAnimationFrame(animationFrame);animationFrame=0;lastFrameTime=0;$('fxCanvas').getContext('2d').clearRect(0,0,innerWidth,innerHeight)}
function restartAnimation(){if($('settingsModal')?.open)return;
  stopAnimation();particles=[];resizeCanvas();
  const m=prefersReducedMotion.matches?'none':config.settings.motionType;
  const signature=`${m}|${config.settings.particleCount}|${innerWidth}x${innerHeight}`;
  lastMotionSignature=signature;
  if(CANVAS_MOTIONS.has(m)&&!document.hidden){initParticles(m);animationFrame=requestAnimationFrame(drawFx)}
}
function initParticles(type){
  let n=Math.min(Number(config.settings.particleCount)||0,LOW_POWER_DEVICE?64:120);
  if(type==='constellation')n=Math.min(n,LOW_POWER_DEVICE?34:58);
  if(type==='comets')n=Math.min(n,LOW_POWER_DEVICE?24:38);
  if(type==='fireflies')n=Math.min(n,LOW_POWER_DEVICE?44:78);
  const scale=Math.max(.65,Number(config.settings.motionScale||100)/100);
  for(let i=0;i<n;i++)particles.push({x:Math.random()*innerWidth,y:Math.random()*innerHeight,vx:(Math.random()-.5)*.34,vy:(Math.random()-.5)*.34,r:(Math.random()*2+1)*scale,a:Math.random()*.65+.2,phase:Math.random()*6.28,life:Math.random()});
  if(type==='embers')particles.forEach(p=>{p.y=innerHeight+Math.random()*160;p.vy=-(Math.random()*1.35+.35);p.vx=Math.random()*.65-.325;p.r=(Math.random()*1.9+.8)*scale});
  if(type==='fireflies')particles.forEach(p=>{p.vx=(Math.random()-.5)*.17;p.vy=(Math.random()-.5)*.17;p.r=(Math.random()*1.7+.65)*scale});
  if(type==='comets')particles.forEach(p=>{p.x=Math.random()*innerWidth;p.y=Math.random()*innerHeight*.9;p.vx=-(Math.random()*2.5+2);p.vy=Math.random()*1+.55;p.r=(Math.random()*.9+.45)*scale});
  if(type==='dust')particles.forEach(p=>{p.vx=(Math.random()-.5)*.11;p.vy=(Math.random()-.5)*.07;p.r=(Math.random()*1.15+.25)*scale;p.a=Math.random()*.38+.08});
  if(type==='stars')particles.forEach(p=>{p.r=(Math.random()*1.35+.35)*scale;p.a=Math.random()*.55+.18});
  if(type==='snow')particles.forEach(p=>{p.r=(Math.random()*2.15+1.05)*scale;p.vy=(Math.random()*.42+.22);p.vx=(Math.random()-.5)*.055;p.a=Math.random()*.48+.28;p.phase=Math.random()*Math.PI*2;p.sway=Math.random()*.22+.08});
  if(type==='bubbles')particles.forEach(p=>{p.r=(Math.random()*4.2+2.4)*scale;p.vy=-(Math.random()*.15+.07);p.vx=(Math.random()-.5)*.05;p.a=Math.random()*.22+.08});
}
function drawFx(time=0){
  if(document.hidden||prefersReducedMotion.matches){stopAnimation();return}
  if(time-lastFrameTime<FX_FRAME_INTERVAL){animationFrame=requestAnimationFrame(drawFx);return}
  const delta=Math.min(2,(time-lastFrameTime)/16.67||1);lastFrameTime=time;
  const c=$('fxCanvas'),ctx=c.getContext('2d'),type=config.settings.motionType,intensity=config.settings.motionIntensity/100,speed=(config.settings.motionSpeed/85)*delta,scale=Math.max(.65,config.settings.motionScale/100);
  ctx.clearRect(0,0,innerWidth,innerHeight);
  for(const p of particles){
    if(type==='bubbles'){p.phase+=.008*speed;p.x+=(p.vx+Math.sin(p.phase)*.08)*speed;p.y+=p.vy*speed}
    else if(type==='fireflies'){p.phase+=.018*speed;p.x+=(p.vx+Math.sin(p.phase)*.12)*speed;p.y+=(p.vy+Math.cos(p.phase*.77)*.08)*speed}
    else if(type==='snow'){p.phase+=.009*speed;p.x+=(p.vx+Math.sin(p.phase)*(p.sway||.12))*speed*.62;p.y+=p.vy*speed*.62}
    else{p.x+=p.vx*speed;p.y+=p.vy*speed}
    if(type==='stars')p.a=.18+.64*(.5+.5*Math.sin(p.phase+=.022*speed));
    if(type==='fireflies')p.a=.16+.72*(.5+.5*Math.sin(p.phase*1.7));
    if(type==='dust')p.a=.07+.34*(.5+.5*Math.sin(p.phase+=.006*speed));
    if(p.x<-100)p.x=innerWidth+100;if(p.x>innerWidth+100)p.x=-100;if(p.y<-100)p.y=innerHeight+100;if(p.y>innerHeight+100)p.y=-100;
    ctx.beginPath();
    if(type==='comets'){
      const len=(32+p.r*20)*scale;ctx.moveTo(p.x,p.y);ctx.lineTo(p.x+len,p.y-len*.30);ctx.strokeStyle=`rgba(210,230,255,${Math.min(.82,p.a*intensity)})`;ctx.lineWidth=Math.max(.8,p.r);ctx.shadowBlur=10*scale;ctx.shadowColor='rgba(150,190,255,.5)';ctx.stroke();ctx.shadowBlur=0;
    }else if(type==='bubbles'){
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.strokeStyle=`rgba(220,235,255,${p.a*intensity})`;ctx.lineWidth=Math.max(1,1.15*scale);ctx.shadowBlur=12*scale;ctx.shadowColor='rgba(150,180,255,.18)';ctx.stroke();ctx.shadowBlur=0;
    }else{
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=type==='embers'?`rgba(255,155,65,${p.a*intensity})`:type==='fireflies'?`rgba(205,255,155,${p.a*intensity})`:type==='dust'?`rgba(205,218,255,${p.a*intensity})`:`rgba(245,248,255,${p.a*intensity})`;if(type==='fireflies'){ctx.shadowBlur=10*scale;ctx.shadowColor='rgba(175,255,125,.72)'}if(type==='snow'){ctx.shadowBlur=4*scale;ctx.shadowColor='rgba(255,255,255,.28)'}ctx.fill();ctx.shadowBlur=0;
    }
  }
  if(type==='constellation'){
    const reach=95*scale;ctx.strokeStyle=`rgba(220,228,255,${.13*intensity})`;ctx.lineWidth=.7*scale;for(let i=0;i<particles.length;i++)for(let j=i+1;j<particles.length;j++){const a=particles[i],b=particles[j],dx=a.x-b.x,dy=a.y-b.y,d2=dx*dx+dy*dy;if(d2<reach*reach){ctx.globalAlpha=1-Math.sqrt(d2)/reach;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}}ctx.globalAlpha=1;
  }
  animationFrame=requestAnimationFrame(drawFx);
}

let inlineCompletion='';
