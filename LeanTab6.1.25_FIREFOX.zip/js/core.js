const $ = id => document.getElementById(id);
const STORAGE_KEY = 'leanTabConfig';
const LEGACY_KEY = 'btwNewTabConfig';
const APP_VERSION = browser.runtime.getManifest().version;
const uid = () => crypto.randomUUID?.() || `lt-${Date.now()}-${Math.random().toString(16).slice(2)}`;

const THEMES = {
  midnight:{label:'Midnight',preview:'linear-gradient(135deg,#05060b,#22265a,#663c9a)',bg:'radial-gradient(circle at 78% 18%,#3547a7 0,transparent 31%),radial-gradient(circle at 15% 84%,#6e2f87 0,transparent 36%),linear-gradient(145deg,#03040a,#111529 55%,#08060d)'},
  aurora:{label:'Aurora',preview:'linear-gradient(135deg,#031d25,#00a88f,#7751e8)',bg:'radial-gradient(circle at 16% 20%,#00a88f 0,transparent 34%),radial-gradient(circle at 82% 24%,#7751e8 0,transparent 37%),radial-gradient(circle at 48% 88%,#126f60 0,transparent 38%),linear-gradient(145deg,#021317,#081a25)'},
  cyberpunk:{label:'Cyberpunk',preview:'linear-gradient(135deg,#fcee0a,#ff003c,#00f0ff)',bg:'radial-gradient(circle at 75% 20%,#ff003c 0,transparent 30%),radial-gradient(circle at 15% 80%,#00f0ff 0,transparent 35%),linear-gradient(145deg,#1a1a1a,#2b0010 50%,#001a1f)'},
  lavender:{label:'Lavender',preview:'linear-gradient(135deg,#e6e6fa,#c8b4e2,#9370db)',bg:'radial-gradient(circle at 70% 25%,#c8b4e2 0,transparent 35%),radial-gradient(circle at 20% 75%,#9370db 0,transparent 40%),linear-gradient(145deg,#0a0510,#150c22 55%,#0f0518)'},
  ember:{label:'Ember',preview:'linear-gradient(135deg,#190705,#e86a13,#9c173f)',bg:'radial-gradient(circle at 70% 18%,#e86a13 0,transparent 31%),radial-gradient(circle at 18% 82%,#9c173f 0,transparent 38%),linear-gradient(140deg,#160604,#421209 50%,#080303)'},
  ocean:{label:'Ocean',preview:'linear-gradient(135deg,#020a18,#0076c7,#00b8d9)',bg:'radial-gradient(circle at 73% 18%,#00a5d9 0,transparent 34%),radial-gradient(circle at 16% 82%,#075c88 0,transparent 38%),linear-gradient(145deg,#020812,#072239 56%,#02070d)'},
  matrix:{label:'Matrix',preview:'linear-gradient(135deg,#010402,#087d43,#59d55f)',bg:'radial-gradient(circle at 74% 22%,#0a7c42 0,transparent 33%),linear-gradient(145deg,#010402,#06150d 58%,#020503)'},
  sunset:{label:'Sunset',preview:'linear-gradient(135deg,#24122f,#f27645,#db2d7b)',bg:'radial-gradient(circle at 74% 20%,#f27645 0,transparent 34%),radial-gradient(circle at 18% 82%,#db2d7b 0,transparent 38%),linear-gradient(145deg,#24122f,#2d183d 58%,#100a1a)'},
  glacier:{label:'Glacier',preview:'linear-gradient(135deg,#e7fbff,#3ca5d7,#0a263f)',bg:'radial-gradient(circle at 75% 20%,#9eeaff 0,transparent 28%),radial-gradient(circle at 15% 78%,#3c9fd8 0,transparent 38%),linear-gradient(145deg,#07131e,#12344d 55%,#06101a)'},
  mono:{label:'Monochrome',preview:'linear-gradient(135deg,#050505,#303030,#858585)',bg:'radial-gradient(circle at 70% 20%,#4c4c4c 0,transparent 32%),radial-gradient(circle at 18% 80%,#242424 0,transparent 36%),linear-gradient(145deg,#030303,#141414 58%,#080808)'},
  neon:{label:'Neon City',preview:'linear-gradient(135deg,#12051d,#ff1da6,#00bfe9)',bg:'radial-gradient(circle at 72% 18%,#00bfe9 0,transparent 31%),radial-gradient(circle at 18% 78%,#ff1da6 0,transparent 37%),linear-gradient(145deg,#100419,#241132 56%,#07030d)'},
  forest:{label:'Forest',preview:'linear-gradient(135deg,#06120b,#34784d,#9c7a30)',bg:'radial-gradient(circle at 75% 18%,#34784d 0,transparent 34%),radial-gradient(circle at 15% 82%,#7c682a 0,transparent 36%),linear-gradient(145deg,#051009,#11291b 56%,#060b07)'},
  sakura:{label:'Sakura',preview:'linear-gradient(135deg,#261022,#d76391,#f1b5c8)',bg:'radial-gradient(circle at 72% 20%,#d76391 0,transparent 31%),radial-gradient(circle at 18% 82%,#8d4f8a 0,transparent 38%),linear-gradient(145deg,#24101f,#3b1830 55%,#120916)'},
  desert:{label:'Desert',preview:'linear-gradient(135deg,#28170d,#b96b2c,#dbb06a)',bg:'radial-gradient(circle at 75% 18%,#bd7137 0,transparent 33%),radial-gradient(circle at 16% 82%,#8e3f28 0,transparent 38%),linear-gradient(145deg,#21130b,#3b2214 58%,#100905)'},
  ultraviolet:{label:'Ultraviolet',preview:'linear-gradient(135deg,#070417,#5534d6,#ba43ed)',bg:'radial-gradient(circle at 74% 18%,#5534d6 0,transparent 32%),radial-gradient(circle at 16% 82%,#ba43ed 0,transparent 37%),linear-gradient(145deg,#060313,#17103a 55%,#070313)'},
  nord:{label:'Nord',preview:'linear-gradient(135deg,#081017,#35526d,#8bb8d1)',bg:'radial-gradient(circle at 74% 20%,#35526d 0,transparent 32%),radial-gradient(circle at 17% 82%,#4b6e78 0,transparent 37%),linear-gradient(145deg,#071018,#132431 56%,#060b10)'},
  coffee:{label:'Coffee',preview:'linear-gradient(135deg,#120b08,#70412b,#bd8b63)',bg:'radial-gradient(circle at 72% 20%,#70412b 0,transparent 33%),radial-gradient(circle at 18% 82%,#4b2d24 0,transparent 38%),linear-gradient(145deg,#100906,#281711 57%,#090503)'},
  candy:{label:'Candy',preview:'linear-gradient(135deg,#281039,#7e5be7,#ec5da7)',bg:'radial-gradient(circle at 74% 18%,#7e5be7 0,transparent 32%),radial-gradient(circle at 18% 82%,#ec5da7 0,transparent 38%),linear-gradient(145deg,#241033,#3b1d55 57%,#11081b)'},
  solar:{label:'Solar',preview:'linear-gradient(135deg,#130d04,#d58a18,#f2d15a)',bg:'radial-gradient(circle at 72% 18%,#d58a18 0,transparent 31%),radial-gradient(circle at 18% 82%,#8c4f17 0,transparent 38%),linear-gradient(145deg,#120c04,#2c1c09 58%,#080502)'},
  crimson:{label:'Crimson',preview:'linear-gradient(135deg,#120305,#8f1027,#e43f5a)',bg:'radial-gradient(circle at 75% 18%,#a31330 0,transparent 32%),radial-gradient(circle at 17% 82%,#551020 0,transparent 37%),linear-gradient(145deg,#100205,#290710 57%,#070103)'},
  obsidian:{label:'Obsidian',preview:'linear-gradient(135deg,#020204,#15151d,#57536b)',bg:'radial-gradient(circle at 74% 18%,#3e3b58 0,transparent 30%),radial-gradient(circle at 15% 82%,#201d35 0,transparent 38%),linear-gradient(145deg,#010103,#0c0c12 58%,#030305)'},
  mint:{label:'Mint Glass',preview:'linear-gradient(135deg,#051513,#4fd1b5,#a7f3d0)',bg:'radial-gradient(circle at 76% 18%,#43c6ac 0,transparent 31%),radial-gradient(circle at 18% 82%,#147d72 0,transparent 38%),linear-gradient(145deg,#03100e,#0b2824 58%,#020807)'},
  cobalt:{label:'Cobalt',preview:'linear-gradient(135deg,#03091d,#155eef,#67e8f9)',bg:'radial-gradient(circle at 75% 18%,#155eef 0,transparent 31%),radial-gradient(circle at 16% 82%,#0891b2 0,transparent 38%),linear-gradient(145deg,#020617,#0b1f4d 58%,#02040d)'},
  roseGold:{label:'Rose Gold',preview:'linear-gradient(135deg,#28141b,#d68d8b,#f4c6a7)',bg:'radial-gradient(circle at 74% 18%,#c97c7b 0,transparent 32%),radial-gradient(circle at 17% 82%,#8f4660 0,transparent 37%),linear-gradient(145deg,#1a0b10,#3b1d25 57%,#0c0508)'},
  lime:{label:'Lime Noir',preview:'linear-gradient(135deg,#050705,#8ecf32,#d9f99d)',bg:'radial-gradient(circle at 74% 20%,#75b72e 0,transparent 32%),radial-gradient(circle at 17% 82%,#355d1b 0,transparent 37%),linear-gradient(145deg,#040604,#101b0b 56%,#020302)'},
  plasma:{label:'Plasma',preview:'linear-gradient(135deg,#15051d,#7c3aed,#f97316)',bg:'radial-gradient(circle at 75% 18%,#7c3aed 0,transparent 32%),radial-gradient(circle at 17% 82%,#f97316 0,transparent 37%),linear-gradient(145deg,#100318,#28113b 56%,#08020c)'},
  icePink:{label:'Ice Pink',preview:'linear-gradient(135deg,#07131b,#66d9ef,#f0abfc)',bg:'radial-gradient(circle at 75% 18%,#54c9e8 0,transparent 31%),radial-gradient(circle at 17% 82%,#d78eea 0,transparent 38%),linear-gradient(145deg,#061018,#122c3a 56%,#05070e)'},
  graphite:{label:'Graphite',preview:'linear-gradient(135deg,#050505,#292b30,#747985)',bg:'radial-gradient(circle at 72% 18%,#383b43 0,transparent 31%),radial-gradient(circle at 18% 82%,#1f2228 0,transparent 38%),linear-gradient(145deg,#030303,#111318 57%,#050505)'},
  amethyst:{label:'Amethyst',preview:'linear-gradient(135deg,#11051f,#8b5cf6,#e879f9)',bg:'radial-gradient(circle at 76% 18%,#8b5cf6 0,transparent 31%),radial-gradient(circle at 16% 82%,#c026d3 0,transparent 38%),linear-gradient(145deg,#0c0316,#25103d 57%,#06020a)'},
  lagoon:{label:'Lagoon',preview:'linear-gradient(135deg,#021312,#0f9f8f,#6ee7d8)',bg:'radial-gradient(circle at 74% 18%,#18b8a5 0,transparent 31%),radial-gradient(circle at 16% 82%,#176b78 0,transparent 39%),linear-gradient(145deg,#02100f,#082a2c 57%,#020707)'},
  velvet:{label:'Velvet',preview:'linear-gradient(135deg,#18050d,#9f174d,#f59e8b)',bg:'radial-gradient(circle at 76% 18%,#a81b54 0,transparent 31%),radial-gradient(circle at 17% 82%,#73314f 0,transparent 38%),linear-gradient(145deg,#120309,#351023 57%,#080205)'},
  arctic:{label:'Arctic',preview:'linear-gradient(135deg,#051018,#5685a6,#d7f5ff)',bg:'radial-gradient(circle at 76% 18%,#75b7d8 0,transparent 29%),radial-gradient(circle at 16% 82%,#416d89 0,transparent 38%),linear-gradient(145deg,#041019,#112d3d 57%,#03080c)'}
};

const THEME_ACCENTS = {
  midnight:'#8b7cff',aurora:'#2dd4bf',cyberpunk:'#ff3b9d',lavender:'#b99cff',ember:'#f97316',ocean:'#22b8e6',matrix:'#38d66b',sunset:'#f56b75',
  glacier:'#65c9f3',mono:'#a3a3a3',neon:'#ec45be',forest:'#4da56b',sakura:'#e879a5',desert:'#d68a43',ultraviolet:'#7c5cff',nord:'#6f9fbd',
  coffee:'#b98262',candy:'#a978f4',solar:'#f1b93a',crimson:'#e13d59',obsidian:'#77738f',mint:'#58d6bc',cobalt:'#3487ff',roseGold:'#df9894',
  lime:'#91d83b',plasma:'#9c55f5',icePink:'#74dff2',graphite:'#747984',amethyst:'#a76cf7',lagoon:'#2cc9b2',velvet:'#cc3972',arctic:'#82c4e7'
};


const MOTIONS = [
  ['none','Без анимации'],
  ['drift','Кинематографичный дрейф'],
  ['aurora','Северное сияние'],
  ['mesh','Живой градиент'],
  ['nebula','Туманность'],
  ['silk','Шёлковые переливы'],
  ['liquid','Жидкое стекло'],
  ['ribbons','Цветные ленты'],
  ['waves','Световые волны'],
  ['halo','Мягкие ореолы'],
  ['snow','Медленный снег'],
  ['bokeh','Мягкое боке'],
  ['bloom','Цветовое свечение'],
  ['chroma','Хроматические облака'],
  ['veil','Космическая вуаль'],
  ['stars','Глубокое звёздное поле'],
  ['fireflies','Светлячки'],
  ['comets','Метеорный поток'],
  ['bubbles','Парящие сферы'],
  ['embers','Тёплые искры'],
  ['constellation','Созвездия'],
  ['dust','Космическая пыль']
];
const ZONES = ['top','bottom','left','right'];
const zoneDefaults = {top:{inset:40,shift:0,gap:10,max:40},bottom:{inset:40,shift:0,gap:10,max:40},left:{inset:40,shift:0,gap:10,max:40},right:{inset:40,shift:0,gap:10,max:40}};
const defaults = {
  folders:[
    {id:uid(),name:'Работа',zone:'top',color:'#8b5cf6'}
  ],
  links:[
    {id:uid(),title:'YouTube',url:'https://youtube.com',iconMode:'favicon',color:'#ff0033',zone:'left'},
    {id:uid(),title:'ChatGPT',url:'https://chatgpt.com',iconMode:'favicon',color:'#ffffff',zone:'right'},
    {id:uid(),title:'Gmail',url:'https://mail.google.com',iconMode:'favicon',color:'#ea4335',zone:'bottom'}
  ],
  settings:{language:'ru',theme:'midnight',customBg:'',customBgEffects:false,overlayOpacity:58,saturation:140,backgroundFit:'cover',backgroundPositionX:50,glassEffect:true,fontFamily:"ui-sans-serif,system-ui,-apple-system,'Segoe UI',sans-serif",clockFont:"Impact,Haettenschweiler,'Arial Narrow Bold',sans-serif",clockSize:180,dateSize:20,dateColor:'#ffffff',dateOpacity:55,clockWeight:600,clockSpacing:7,clockGlow:35,userName:'',showGreeting:true,showDate:true,use24h:true,showSeconds:false,tileScale:120,tileRadius:18,tileOpacity:8,tileAccentIntensity:55,tileHoverEffect:'soft',tileClickEffect:'press',tileEffectIntensity:45,showLabels:true,showSearch:true,searchWidth:700,searchHeight:64,motionType:'stars',motionSpeed:120,motionIntensity:70,motionScale:190,particleCount:150,showZones:false,uiScale:100,lockTiles:false,hideAddButtons:false,searchHistoryEnabled:true,searchHistoryLimit:40,searchHistoryDays:0,privateSearch:false,zones:structuredClone(zoneDefaults)}
};
let config = structuredClone(defaults), editingId = null, editingFolderId = null, profiles = {}, uploadedIcon = '', animationFrame = 0, particles = [], resizeTimer, liveApplyFrame = 0, animationRestartTimer = 0, lastMotionSignature = '', lastFrameTime = 0, settingsSnapshot = null, settingsDirty = false;
const prefersReducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const CANVAS_MOTIONS = new Set(['particles','stars','fireflies','comets','rain','bubbles','orbits','snow','embers','constellation','dust']);
const IMAGE_TYPES = new Set(['image/jpeg','image/png','image/webp','image/gif']);
const SEARCH_HISTORY_KEY = 'leanTabSearchHistory';
const DEFAULT_SEARCH_HISTORY_LIMIT = 40;
const PROFILES_KEY = 'leanTabProfiles';
const PROFILE_FORMAT_VERSION = 2;
const SEARCH_SUGGESTION_LIMIT = 8;
let searchHistory = [], searchSuggestions = [], activeSuggestion = -1, suggestionTimer = 0, suggestionController = null;
const BG_MAX_BYTES = 15 * 1024 * 1024;
const ICON_MAX_BYTES = 3 * 1024 * 1024;
const clamp = (value,min,max,fallback=min) => { const n=Number(value); return Number.isFinite(n)?Math.min(max,Math.max(min,n)):fallback };
// Single source of truth for every numeric setting. Values loaded from old
// builds, imports/profiles and live form input all pass through this schema.
const SETTING_RANGES = Object.freeze({
  uiScale:[60,160,100],searchHistoryLimit:[20,300,40],searchHistoryDays:[0,3650,0],
  overlayOpacity:[0,90,28],saturation:[40,180,110],backgroundPositionX:[0,100,50],
  motionSpeed:[15,220,85],motionIntensity:[5,100,65],motionScale:[100,190,130],particleCount:[15,150,65],
  clockSize:[36,250,180],dateSize:[10,40,15],dateOpacity:[10,100,55],clockWeight:[200,900,500],clockSpacing:[-12,12,-7],clockGlow:[0,100,35],
  searchWidth:[240,1400,560],searchHeight:[42,90,54],tileScale:[50,220,100],tileRadius:[4,42,18],tileOpacity:[8,55,24],
  tileAccentIntensity:[0,100,55],tileEffectIntensity:[10,100,45]
});
const ZONE_RANGES = Object.freeze({inset:[0,180],shift:[-320,320],gap:[0,40],max:[20,40]});
function normalizeNumericSettings(settings){
  for(const [key,[min,max,fallback]] of Object.entries(SETTING_RANGES)) settings[key]=clamp(settings[key],min,max,fallback);
  settings.zones=settings.zones&&typeof settings.zones==='object'?settings.zones:{};
  for(const z of ZONES){
    const source=settings.zones[z]&&typeof settings.zones[z]==='object'?settings.zones[z]:{};
    const fallback=zoneDefaults[z];
    settings.zones[z]={
      inset:clamp(source.inset,...ZONE_RANGES.inset,fallback.inset),
      shift:clamp(source.shift,...ZONE_RANGES.shift,fallback.shift),
      gap:clamp(source.gap,...ZONE_RANGES.gap,fallback.gap),
      max:clamp(source.max,...ZONE_RANGES.max,Math.min(fallback.max,ZONE_RANGES.max[1]))
    };
  }
  return settings;
}
const safeText = (value,max=200) => String(value ?? '').trim().slice(0,max);
const validColor = value => /^#[0-9a-f]{6}$/i.test(value||'') ? value : '#8b5cf6';
function safeUrl(value){ try { const url=new URL(normalizeUrl(String(value||''))); return ['http:','https:'].includes(url.protocol)?url.href:'https://example.com/'; } catch { return 'https://example.com/'; } }


function createProfileSnapshot(){
  return {
    profileFormatVersion: PROFILE_FORMAT_VERSION,
    savedAt: new Date().toISOString(),
    config: structuredClone(config)
  };
}
function profileToConfig(entry){
  // Profiles created before the sizing rewrite stored the whole config directly.
  // Their uiScale was based on CSS zoom and must not be multiplied into clocks,
  // search and tiles by the new safe sizing engine.
  if(entry && typeof entry==='object' && entry.profileFormatVersion===PROFILE_FORMAT_VERSION && entry.config){
    return mergeConfig(entry.config);
  }
  const legacy=mergeConfig(entry && entry.config ? entry.config : entry);
  legacy.settings.uiScale=100;
  // searchHeight did not exist in the original profile format.
  if(!entry?.settings || !Object.prototype.hasOwnProperty.call(entry.settings,'searchHeight')) legacy.settings.searchHeight=54;
  return legacy;
}

function mergeConfig(raw={}){
  const migrated = structuredClone(defaults);
  const source = raw && typeof raw==='object' ? raw : {};
  if(Array.isArray(source.folders)) migrated.folders=source.folders.slice(0,100).map(x=>({id:safeText(x?.id,120)||uid(),name:safeText(x?.name,32)||tr('Папка'),zone:ZONES.includes(x?.zone)?x.zone:'bottom',color:validColor(x?.color)}));
  if(Array.isArray(source.links)) migrated.links = source.links.slice(0,250).map(x=>({
    id:safeText(x?.id,120)||uid(), title:safeText(x?.title,32)||tr('Ссылка'), url:safeUrl(x?.url),
    iconMode:['favicon','emoji','initials','upload'].includes(x?.iconMode)?x.iconMode:'favicon',
    emoji:safeText(x?.emoji,8), color:validColor(x?.color), zone:ZONES.includes(x?.zone)?x.zone:'bottom', folderId:safeText(x?.folderId,120),
    ...(typeof x?.iconData==='string' && x.iconData.startsWith('data:image/') ? {iconData:x.iconData} : {})
  }));
  const incoming=source.settings&&typeof source.settings==='object'?source.settings:{};
  migrated.settings={...migrated.settings,...incoming};
  delete migrated.settings.tileWidth; // obsolete setting from 5.1 experimental builds
  migrated.settings.language=['ru','en'].includes(migrated.settings.language)?migrated.settings.language:browserDefaultLanguage;
  migrated.settings.theme=THEMES[migrated.settings.theme]?migrated.settings.theme:'midnight';
  migrated.settings.fontFamily=incoming.fontFamily||defaults.settings.fontFamily; migrated.settings.clockFont=incoming.clockFont||defaults.settings.clockFont;
  if(migrated.settings.motionType==='prism')migrated.settings.motionType='snow';
  migrated.settings.motionType=MOTIONS.some(([v])=>v===migrated.settings.motionType)?migrated.settings.motionType:'aurora';
  migrated.settings.backgroundFit=['cover','contain','fill'].includes(migrated.settings.backgroundFit)?migrated.settings.backgroundFit:'cover';
  migrated.settings.tileHoverEffect=['none','soft','lift','glow','zoom','tilt','shimmer','outline','icon'].includes(migrated.settings.tileHoverEffect)?migrated.settings.tileHoverEffect:'soft';
  migrated.settings.tileClickEffect=['none','press','pulse','snap','bounce','flash','sink'].includes(migrated.settings.tileClickEffect)?migrated.settings.tileClickEffect:'press';
  migrated.settings.userName=safeText(migrated.settings.userName,24);
  migrated.settings.dateColor=validColor(migrated.settings.dateColor||'#ffffff');
  normalizeNumericSettings(migrated.settings);
  for(const key of ['customBgEffects','glassEffect','showGreeting','showDate','use24h','showSeconds','showSearch','showLabels','showZones','lockTiles','hideAddButtons','searchHistoryEnabled','privateSearch']) migrated.settings[key]=Boolean(migrated.settings[key]);
  migrated.settings.customBg=typeof incoming.customBg==='string'&&incoming.customBg.startsWith('data:image/')?incoming.customBg:'';
  // Re-normalize zones after spreading incoming settings so legacy values
  // such as 100% cannot re-enter the renderer.
  migrated.settings.zones=incoming.zones||migrated.settings.zones;
  normalizeNumericSettings(migrated.settings);
  return migrated;
}
const ASSET_DB='leanTabAssets', ASSET_STORE='assets';
function openAssetDb(){return new Promise((resolve,reject)=>{const req=indexedDB.open(ASSET_DB,1);req.onupgradeneeded=()=>{if(!req.result.objectStoreNames.contains(ASSET_STORE))req.result.createObjectStore(ASSET_STORE)};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error||new Error('IndexedDB unavailable'));req.onblocked=()=>reject(new Error('IndexedDB blocked'))})}
async function assetSet(key,value){const db=await openAssetDb();return new Promise((resolve,reject)=>{const tx=db.transaction(ASSET_STORE,'readwrite');tx.objectStore(ASSET_STORE).put(value,key);tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error||new Error('IndexedDB transaction failed'))};tx.onabort=()=>{db.close();reject(tx.error||new Error('IndexedDB transaction aborted'))}})}
async function assetGet(key){const db=await openAssetDb();return new Promise((resolve,reject)=>{const tx=db.transaction(ASSET_STORE,'readonly'),req=tx.objectStore(ASSET_STORE).get(key);req.onsuccess=()=>{db.close();resolve(req.result||'')};req.onerror=()=>{db.close();reject(req.error)}})}
async function assetDelete(key){const db=await openAssetDb();return new Promise((resolve,reject)=>{const tx=db.transaction(ASSET_STORE,'readwrite');tx.objectStore(ASSET_STORE).delete(key);tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error||new Error('IndexedDB transaction failed'))};tx.onabort=()=>{db.close();reject(tx.error||new Error('IndexedDB transaction aborted'))}})}
async function clearAssets(){const db=await openAssetDb();return new Promise((resolve,reject)=>{const tx=db.transaction(ASSET_STORE,'readwrite');tx.objectStore(ASSET_STORE).clear();tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error||new Error('IndexedDB transaction failed'))};tx.onabort=()=>{db.close();reject(tx.error||new Error('IndexedDB transaction aborted'))}})}
function storageSafeConfig(){const copy=structuredClone(config);normalizeNumericSettings(copy.settings);copy.settings.customBg='';copy.links=copy.links.map(x=>{const y={...x};delete y.iconData;return y});return copy}
async function save(){
  try{await browser.storage.local.set({[STORAGE_KEY]:storageSafeConfig()});return true}
  catch(err){console.error('LeanTab save failed',err);toast?.(tr('Не удалось сохранить настройки'));return false}
}
async function migrateAssets(raw){
  const bg=raw?.settings?.customBg;if(bg){try{await assetSet('background',bg)}catch(e){console.warn('Background migration failed',e)}}
  for(const link of raw?.links||[]){if(link?.id&&link.iconData){try{await assetSet('icon:'+link.id,link.iconData)}catch(e){console.warn('Icon migration failed',e)}}}
}
async function hydrateAssets(){
  try{config.settings.customBg=await assetGet('background')}catch{config.settings.customBg=''}
  await Promise.all(config.links.map(async link=>{if(link.iconMode==='upload'){try{link.iconData=await assetGet('icon:'+link.id)}catch{link.iconData=''}}}))
}
async function persistAssetsFromConfig(){
  if(config.settings.customBg) await assetSet('background',config.settings.customBg); else await assetDelete('background').catch(()=>{});
  const keep=new Set();
  for(const link of config.links){ if(link.iconMode==='upload'&&link.iconData){ const key='icon:'+link.id; keep.add(key); await assetSet(key,link.iconData) } }
  return keep;
}
async function load(){
  const SCALE_RECOVERY_KEY='leanTabScaleRecoveryV2';
  const data = await browser.storage.local.get([STORAGE_KEY,LEGACY_KEY,SCALE_RECOVERY_KEY]);
  const raw=data[STORAGE_KEY] || data[LEGACY_KEY] || defaults;
  config = mergeConfig(raw);

  // One-time recovery for builds that scaled the complete application and
  // could move tiles and the settings button outside the viewport.
  if(!data[SCALE_RECOVERY_KEY]){
    config.settings.uiScale=100;
    await browser.storage.local.set({[SCALE_RECOVERY_KEY]:true});
  }

  // Remove any legacy inline scaling left by older builds.
  for(const element of [document.documentElement,document.body,document.querySelector('.app')]){
    if(!element)continue;
    element.style.removeProperty('zoom');
    element.style.removeProperty('scale');
    element.style.removeProperty('transform');
    element.style.removeProperty('transform-origin');
  }

  await migrateAssets(raw);
  await hydrateAssets();
  if(!data[STORAGE_KEY] || !data[SCALE_RECOVERY_KEY]) await save();
}
function cssVar(name,value){document.documentElement.style.setProperty(name,value)}
function getEffectiveUiScale(settings=config.settings){
  const requested=Math.max(.6,Math.min(1.6,Number(settings.uiScale||100)/100));
  const widthCap=Math.max(.72,Math.min(1.6,innerWidth/1120));
  const heightCap=Math.max(.72,Math.min(1.6,innerHeight/680));
  return {requested,effective:Math.min(requested,Math.min(widthCap,heightCap))};
}
function applyVisualSettings({restartFx=true, render=true}={}){
  const s=normalizeNumericSettings(config.settings);
  document.body.dataset.motion=prefersReducedMotion.matches||s.customBg&&!s.customBgEffects?'none':s.motionType;
  document.body.classList.toggle('hide-labels',!s.showLabels);
  document.body.classList.toggle('show-zones',s.showZones);
  document.body.classList.toggle('glass-enabled',s.glassEffect);
  document.body.classList.toggle('no-glass',!s.glassEffect);
  document.body.classList.toggle('tiles-locked',s.lockTiles);
  for(const name of ['none','soft','lift','glow','zoom','tilt','shimmer','outline','icon'])document.body.classList.toggle(`tile-hover-${name}`,s.tileHoverEffect===name);
  for(const name of ['none','press','pulse','snap','bounce','flash','sink'])document.body.classList.toggle(`tile-click-${name}`,s.tileClickEffect===name);
  document.body.classList.toggle('hide-add-buttons',Boolean(s.hideAddButtons));
  const themeAccent=THEME_ACCENTS[s.theme]||'#8b7cff';
  cssVar('--accent-ui',themeAccent);
  cssVar('--theme-accent',themeAccent);
  const tileFx=Math.max(0.1,Math.min(1,(Number(s.tileEffectIntensity)||45)/100));
  cssVar('--tile-effect-intensity',tileFx);
  cssVar('--tile-fx-lift-soft',`${1+3*tileFx}px`);
  cssVar('--tile-fx-lift',`${3+6*tileFx}px`);
  cssVar('--tile-fx-scale',1+0.025*tileFx);
  cssVar('--tile-fx-press-scale',1-0.045*tileFx);
  cssVar('--tile-fx-soft-glow',`${5+7*tileFx}px`);
  cssVar('--tile-fx-glow',`${7+12*tileFx}px`);
  cssVar('--tile-fx-icon-glow',`${5+8*tileFx}px`);
  cssVar('--tile-fx-soft-border',`${18+24*tileFx}%`);
  cssVar('--tile-fx-lift-border',`${14+22*tileFx}%`);
  cssVar('--tile-fx-glow-border',`${24+28*tileFx}%`);
  cssVar('--tile-fx-soft-accent',`${2+5*tileFx}%`);
  cssVar('--tile-fx-soft-shadow-accent',`${5+10*tileFx}%`);
  cssVar('--tile-fx-glow-shadow-accent',`${10+17*tileFx}%`);
  cssVar('--tile-fx-icon-shadow-accent',`${12+16*tileFx}%`);
  cssVar('--tile-fx-after-opacity',0.25+0.45*tileFx);
  cssVar('--tile-fx-pulse-brightness',1+0.08*tileFx);

  // UI scale is applied to the actual visual dimensions instead of CSS zoom.
  // This keeps all fixed/absolute coordinates stable and leaves settings accessible.
  const {requested:requestedUiScale,effective:effectiveUiScale}=getEffectiveUiScale(s);
  cssVar('--ui-scale',requestedUiScale);
  cssVar('--ui-scale-effective',effectiveUiScale);
  document.body.classList.toggle('ui-scale-capped',effectiveUiScale+0.001<requestedUiScale);

  cssVar('--font-family',defaults.settings.fontFamily);
  cssVar('--clock-font',s.clockFont);
  // Hard render guard: UI scale must never push the clock past the safe visual cap.
  cssVar('--clock-size',`${Math.round(Math.min(250,s.clockSize*effectiveUiScale))}px`);
  cssVar('--date-size',`${Math.round(s.dateSize*effectiveUiScale)}px`);
  cssVar('--date-color',validColor(s.dateColor||'#ffffff'));
  cssVar('--date-opacity',String(Math.max(.1,Math.min(1,(Number(s.dateOpacity)||55)/100))));
  cssVar('--clock-weight',s.clockWeight);
  const safeSpacing=Math.max(-0.08,Math.min(0.12,(Number(s.clockSpacing)||0)/100));
  cssVar('--clock-spacing',`${safeSpacing}em`);
  cssVar('--clock-glow',s.clockGlow/100);

  // Tile size and tile width are independent, predictable controls.
  // Size changes height, icon, text and padding. Width sets the same explicit
  // width for tiles in every zone instead of acting only as a max-width.
  const tileScale=(s.tileScale/100)*effectiveUiScale;
  cssVar('--user-tile-scale',tileScale);
  cssVar('--tile-scale',tileScale);
  cssVar('--tile-height',`${58*tileScale}px`);
  cssVar('--tile-min-width',`${58*tileScale}px`);
  cssVar('--tile-max-width',`${190*tileScale}px`);
  cssVar('--tile-pad-y',`${9*tileScale}px`);
  cssVar('--tile-pad-x',`${12*tileScale}px`);
  cssVar('--tile-icon-size',`${29*tileScale}px`);
  cssVar('--tile-font-size',`${14*tileScale}px`);
  cssVar('--tile-radius',`${s.tileRadius}px`);
  cssVar('--tile-opacity',s.tileOpacity/100);
  const tileAccent=Math.max(0,Math.min(1,(Number(s.tileAccentIntensity)??55)/100));
  cssVar('--tile-accent-opacity',(0.38*tileAccent).toFixed(3));
  cssVar('--tile-accent-opacity-solid',(0.22*tileAccent).toFixed(3));
  cssVar('--tile-border-opacity',Math.max(.05,Math.min(.16,s.tileOpacity/100*.22)));
  cssVar('--tile-blur','14px');

  const searchWidth=Math.round(s.searchWidth*effectiveUiScale);
  const searchHeight=Math.round(s.searchHeight*effectiveUiScale);
  cssVar('--search-width',`${searchWidth}px`);
  cssVar('--search-height',`${searchHeight}px`);
  cssVar('--motion-opacity',s.motionIntensity/100);
  cssVar('--motion-scale',s.motionScale/100);
  cssVar('--motion-duration',`${Math.max(7,235-s.motionSpeed)/10}s`);
  cssVar('--saturation',s.customBg&&!s.customBgEffects?1:s.saturation/100);
  cssVar('--background-size',s.backgroundFit==='fill'?'100% 100%':s.backgroundFit);
  cssVar('--background-position',`${s.backgroundPositionX}% 50%`);

  const overlay=s.overlayOpacity/100;
  const customOverlay=s.customBg&&!s.customBgEffects?0:overlay;
  const bg=s.customBg?`linear-gradient(rgba(0,0,0,${customOverlay}),rgba(0,0,0,${customOverlay})),url("${s.customBg}")`:`linear-gradient(rgba(0,0,0,${overlay}),rgba(0,0,0,${overlay})),${THEMES[s.theme].bg}`;
  if($('background').style.backgroundImage!==bg)$('background').style.backgroundImage=bg;
  $('greeting').hidden=!s.showGreeting;
  $('dateText').hidden=!s.showDate;
  $('searchForm').hidden=!s.showSearch;

  for(const z of ZONES){
    const el=document.querySelector(`.zone${z[0].toUpperCase()+z.slice(1)}`),zs=s.zones[z];
    el.style.setProperty('--zone-inset',`${zs.inset}px`);
    el.style.setProperty('--zone-shift',`${zs.shift}px`);
    el.style.setProperty('--zone-gap',`${zs.gap}px`);
    el.style.setProperty('--zone-max',`${zs.max}vw`);
  }
  if(render)renderLinks();
  updateClock();
  if(restartFx)scheduleAnimationRestart();
}
function updateResponsiveSafety(){
  const s=config.settings;
  const {effective:effectiveUiScale}=getEffectiveUiScale(s);
  const needsSafe=innerWidth<1180||innerHeight<720||s.searchWidth*effectiveUiScale>innerWidth*.88;
  const compact=innerWidth<1180||innerHeight<720;
  document.body.classList.toggle('responsive-safe',needsSafe);
  document.body.classList.toggle('compact-view',compact);
  document.documentElement.style.setProperty('--safe-clock-cap',`${Math.max(54,Math.min(150,innerHeight*.16))}px`);
  document.documentElement.style.setProperty('--safe-search-cap',`${Math.max(260,innerWidth-48)}px`);
}
function apply(){if(config?.settings?.language&&config.settings.language!==currentLanguage)setLanguage(config.settings.language);updateResponsiveSafety();applyVisualSettings({restartFx:true,render:true})}
function scheduleAnimationRestart(){
  if($('settingsModal')?.open)return;
  clearTimeout(animationRestartTimer);
  animationRestartTimer=setTimeout(()=>restartAnimation(),80);
}
function scheduleLiveApply(){
  if(liveApplyFrame)return;
  liveApplyFrame=requestAnimationFrame(()=>{liveApplyFrame=0;updateResponsiveSafety();applyVisualSettings({restartFx:false,render:false})});
}
function updateClock(){
  const s=config.settings,d=new Date(),opts={hour:'2-digit',minute:'2-digit',hour12:!s.use24h};if(s.showSeconds)opts.second='2-digit';
  $('clock').textContent=d.toLocaleTimeString(localeCode(),opts);
  $('dateText').textContent=d.toLocaleDateString(localeCode(),{weekday:'long',day:'numeric',month:'long'});
  const h=d.getHours(),part=h<6?tr('Доброй ночи'):h<12?tr('Доброе утро'):h<18?tr('Добрый день'):tr('Добрый вечер');$('greeting').textContent=s.userName?`${part}, ${s.userName}`:part;
}
let clockTimer=0;
function scheduleClock(){clearTimeout(clockTimer);updateClock();clockTimer=setTimeout(scheduleClock,1000-(Date.now()%1000))}
scheduleClock();
function normalizeUrl(v){v=v.trim();if(!/^https?:\/\//i.test(v))v='https://'+v;return v}
function favicon(url){try{return `https://icons.duckduckgo.com/ip3/${encodeURIComponent(new URL(url).hostname)}.ico`}catch{return ''}}
function makeIcon(link){
  const wrap=document.createElement('span');wrap.className='tileIcon';
  if(link.iconMode==='emoji'){wrap.textContent=link.emoji||'✦';return wrap}
  if(link.iconMode==='initials'){wrap.textContent=(link.title||'').slice(0,2).toUpperCase();return wrap}
  if(link.iconMode==='upload'&&link.iconData){const img=document.createElement('img');img.src=link.iconData;img.alt='';wrap.append(img);return wrap}
  const img=document.createElement('img');img.src=favicon(link.url);img.alt='';img.referrerPolicy='no-referrer';img.addEventListener('error',()=>{wrap.textContent=(link.title||'').slice(0,2).toUpperCase()},{once:true});wrap.append(img);return wrap
}
let draggedLinkId=null;

window.addEventListener('resize',()=>{updateResponsiveSafety();});
