function isLikelyUrl(value){return /^(https?:\/\/|localhost(?::\d+)?|(?:[\w-]+\.)+[a-z]{2,})(?:[\/:?#]|$)/i.test(value)}
async function loadSearchHistory(){try{const stored=await chrome.storage.local.get(SEARCH_HISTORY_KEY);searchHistory=Array.isArray(stored[SEARCH_HISTORY_KEY])?stored[SEARCH_HISTORY_KEY].map(x=>typeof x==='string'?{q:x,t:Date.now()}:x).filter(x=>x&&typeof x.q==='string'):[];pruneSearchHistory()}catch{searchHistory=[]}}
function pruneSearchHistory(){const days=Number(config.settings.searchHistoryDays)||0,cutoff=days?Date.now()-days*86400000:0;searchHistory=searchHistory.filter(x=>x&&typeof x.q==='string'&&(!cutoff||Number(x.t||0)>=cutoff)).slice(0,Number(config.settings.searchHistoryLimit)||DEFAULT_SEARCH_HISTORY_LIMIT)}
async function saveSearchHistory(query){const clean=query.trim();if(!clean||isLikelyUrl(clean)||!config.settings.searchHistoryEnabled||config.settings.privateSearch)return;searchHistory=[{q:clean,t:Date.now()},...searchHistory.filter(x=>x.q.toLocaleLowerCase()!==clean.toLocaleLowerCase())];pruneSearchHistory();try{await chrome.storage.local.set({[SEARCH_HISTORY_KEY]:searchHistory})}catch{}}
async function removeSearchHistory(query){searchHistory=searchHistory.filter(x=>x.q!==query);try{await chrome.storage.local.set({[SEARCH_HISTORY_KEY]:searchHistory})}catch{};updateSearchSuggestions($('searchInput').value.trim(),true)}
async function clearSearchHistory(){if(!searchHistory.length)return;if(!await customConfirm(tr('Очистить всю историю поиска?'),{title:tr('Очистка истории'),okText:tr('Очистить'),danger:true}))return;searchHistory=[];try{await chrome.storage.local.remove(SEARCH_HISTORY_KEY)}catch{};updateSearchSuggestions($('searchInput').value.trim(),true);toast(tr('История поиска очищена'),'success')}
function historyMatches(query){const q=query.toLocaleLowerCase();return searchHistory.map(x=>x.q).filter(x=>!q||x.toLocaleLowerCase().includes(q)).slice(0,SEARCH_SUGGESTION_LIMIT)}
function normalizeRemoteSuggestions(data){
  return Array.isArray(data?.[1])?data[1].filter(x=>typeof x==='string'):[];
}
async function fetchRemoteSuggestions(query){
  if(!query||isLikelyUrl(query))return [];
  suggestionController?.abort();
  suggestionController=new AbortController();
  const url=`https://suggestqueries.google.com/complete/search?client=chrome&q=${encodeURIComponent(query)}`;
  try{
    const response=await fetch(url,{signal:suggestionController.signal,credentials:'omit'});
    if(!response.ok)throw new Error(String(response.status));
    return normalizeRemoteSuggestions(await response.json());
  }catch(error){
    if(error.name!=='AbortError')console.debug('Search suggestions unavailable:',error);
    return [];
  }
}
function updateInlineCompletion(query,items){
  const ghost=$('searchAutocompleteGhost');inlineCompletion='';ghost.replaceChildren();
  if(!query||isLikelyUrl(query))return;
  const lower=query.toLocaleLowerCase();
  const match=items.find(item=>item.value.length>query.length&&item.value.toLocaleLowerCase().startsWith(lower));
  if(!match)return;
  inlineCompletion=match.value;
  const prefix=document.createElement('span');prefix.className='searchGhostPrefix';prefix.textContent=match.value.slice(0,query.length);
  const suffix=document.createElement('span');suffix.className='searchGhostSuffix';suffix.textContent=match.value.slice(query.length);
  ghost.append(prefix,suffix);
}
function acceptInlineCompletion(){
  if(!inlineCompletion)return false;
  const input=$('searchInput');input.value=inlineCompletion;input.setSelectionRange(input.value.length,input.value.length);updateSearchSuggestions(input.value.trim(),true);return true;
}
function fitSearchSuggestions(){
  const box=$('searchSuggestions');if(!box.classList.contains('open'))return;
  box.style.maxHeight='';box.classList.remove('open-upward');
  const form=$('searchForm'),formRect=form.getBoundingClientRect();
  const bottomZone=$('linksBottom')?.closest('.zoneBottom');
  let lowerLimit=window.innerHeight-12;
  if(bottomZone&&!bottomZone.hidden&&getComputedStyle(bottomZone).display!=='none'){
    const zoneRect=bottomZone.getBoundingClientRect();
    if(zoneRect.height>0&&zoneRect.top>formRect.bottom)lowerLimit=Math.min(lowerLimit,zoneRect.top-12);
  }
  const below=Math.max(0,Math.floor(lowerLimit-formRect.bottom-9));
  const above=Math.max(0,Math.floor(formRect.top-12));
  const openUp=below<150&&above>below;
  box.classList.toggle('open-upward',openUp);
  const available=Math.max(96,openUp?above:below);
  box.style.maxHeight=`${Math.min(360,available)}px`;
}
function renderSearchSuggestions(items){
  const box=$('searchSuggestions'),input=$('searchInput'),query=input.value.trim();searchSuggestions=items;activeSuggestion=-1;
  box.replaceChildren();updateInlineCompletion(query,items);
  if(!items.length&&!searchHistory.length){box.classList.remove('open');input.setAttribute('aria-expanded','false');return}
  const list=document.createElement('div');list.className='searchSuggestionList';
  items.forEach((item,index)=>{
    const row=document.createElement('div');row.className='searchSuggestion';row.role='option';row.tabIndex=-1;row.dataset.index=String(index);
    const icon=document.createElement('span');icon.className='searchSuggestionIcon';icon.textContent=item.type==='history'?'↶':'⌕';
    const text=document.createElement('span');text.className='searchSuggestionText';text.textContent=item.value;
    const meta=document.createElement('span');meta.className='searchSuggestionMeta';meta.textContent=item.type==='history'?tr('История'):'';
    row.append(icon,text,meta);
    if(item.type==='history'){const remove=document.createElement('button');remove.type='button';remove.className='searchSuggestionRemove';remove.title=tr('Удалить из истории');remove.setAttribute('aria-label',tr('Удалить из истории'));remove.textContent='×';remove.onclick=e=>{e.stopPropagation();removeSearchHistory(item.value)};row.append(remove)}
    row.onclick=()=>chooseSearchSuggestion(index,true);list.append(row);
  });
  box.append(list);
  if(searchHistory.length){const footer=document.createElement('div');footer.className='searchSuggestionsFooter';const clear=document.createElement('button');clear.type='button';clear.className='clearSearchHistory';clear.textContent=tr('Очистить всю историю');clear.onclick=e=>{e.preventDefault();e.stopPropagation();clearSearchHistory()};footer.append(clear);box.append(footer)}
  box.classList.add('open');input.setAttribute('aria-expanded','true');requestAnimationFrame(fitSearchSuggestions);
}
function chooseSearchSuggestion(index,submit=false){const item=searchSuggestions[index];if(!item)return;$('searchInput').value=item.value;inlineCompletion='';$('searchAutocompleteGhost').replaceChildren();closeSearchSuggestions();if(submit)$('searchForm').requestSubmit()}
function setActiveSuggestion(index){
  if(!searchSuggestions.length)return;activeSuggestion=(index+searchSuggestions.length)%searchSuggestions.length;
  document.querySelectorAll('.searchSuggestion').forEach((el,i)=>{const active=i===activeSuggestion;el.classList.toggle('active',active);el.setAttribute('aria-selected',String(active));if(active)el.scrollIntoView({block:'nearest'})});
}
function closeSearchSuggestions(){clearTimeout(suggestionTimer);suggestionController?.abort();$('searchSuggestions').classList.remove('open');$('searchInput').setAttribute('aria-expanded','false');activeSuggestion=-1}
async function updateSearchSuggestions(query,immediate=false){
  clearTimeout(suggestionTimer);
  const history=historyMatches(query).map(value=>({value,type:'history'}));
  renderSearchSuggestions(history);
  const run=async()=>{
    const remote=await fetchRemoteSuggestions(query);
    if($('searchInput').value.trim()!==query)return;
    const seen=new Set(history.map(x=>x.value.toLocaleLowerCase()));
    const merged=[...history];
    for(const value of remote){
      const clean=value.trim(),key=clean.toLocaleLowerCase();
      if(clean&&!seen.has(key)){seen.add(key);merged.push({value:clean,type:'suggestion'})}
      if(merged.length>=SEARCH_SUGGESTION_LIMIT)break;
    }
    renderSearchSuggestions(merged);
  };
  if(query)suggestionTimer=setTimeout(run,immediate?0:170);
}
async function runSearch(raw){const q=raw.trim();if(!q)return;if(isLikelyUrl(q)){location.href=/^https?:\/\//i.test(q)?q:'https://'+q;return}await saveSearchHistory(q);try{await chrome.search.query({text:q,disposition:'CURRENT_TAB'})}catch(error){console.error('Chrome search failed:',error)}}
$('searchForm').onsubmit=e=>{e.preventDefault();const selected=activeSuggestion>=0?searchSuggestions[activeSuggestion]?.value:$('searchInput').value;closeSearchSuggestions();runSearch(selected||'')};
$('searchInput').addEventListener('input',e=>updateSearchSuggestions(e.target.value.trim()));
$('searchInput').addEventListener('focus',e=>updateSearchSuggestions(e.target.value.trim(),true));
$('searchInput').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();setActiveSuggestion(activeSuggestion+1)}else if(e.key==='ArrowUp'){e.preventDefault();setActiveSuggestion(activeSuggestion-1)}else if(e.key==='Escape'){e.preventDefault();closeSearchSuggestions()}else if(e.key==='Tab'){if(activeSuggestion>=0){e.preventDefault();chooseSearchSuggestion(activeSuggestion,false)}else if(inlineCompletion){e.preventDefault();acceptInlineCompletion()}}else if(e.key==='ArrowRight'&&activeSuggestion<0&&inlineCompletion&&e.target.selectionStart===e.target.value.length&&e.target.selectionEnd===e.target.value.length){e.preventDefault();acceptInlineCompletion()}});
document.addEventListener('pointerdown',e=>{if(!$('searchForm').contains(e.target))closeSearchSuggestions()});

function updateFolderSelect(){const select=$('tileFolder');if(!select)return;const current=select.value;select.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent=tr('Без папки');select.append(empty);for(const folder of config.folders){const option=document.createElement('option');option.value=folder.id;option.textContent=folder.name;select.append(option)}select.value=config.folders.some(f=>f.id===current)?current:''}
function renderFolderManager(){const box=$('folderManagerList');if(!box)return;box.replaceChildren(...config.folders.map(f=>{const b=document.createElement('button');b.type='button';b.className='folderManagerItem';b.textContent=`${f.name} (${config.links.filter(x=>x.folderId===f.id).length})`;b.onclick=()=>openFolderEditor(f.id);return b}))}
function openFolderEditor(id=null){editingFolderId=id;const f=id?config.folders.find(x=>x.id===id):{name:'',zone:'bottom',color:'#8b5cf6'};$('folderModalTitle').textContent=id?tr('Изменить папку'):tr('Новая папка');$('folderName').value=f.name;$('folderZone').value=f.zone;$('folderColor').value=f.color;$('deleteFolder').classList.toggle('hidden',!id);$('folderModal').showModal();requestAnimationFrame(()=>$('folderModal').classList.add('is-open'))}
function closeFolderEditor(){$('folderModal').classList.remove('is-open');setTimeout(()=>{if($('folderModal').open)$('folderModal').close();editingFolderId=null},180)}
function closeFolderEditorAndWait(){const modal=$('folderModal');if(!modal.open)return Promise.resolve();modal.classList.remove('is-open');return new Promise(resolve=>setTimeout(()=>{if(modal.open)modal.close();editingFolderId=null;resolve()},190))}
function renderFolderViewContent(id){
  const f=config.folders.find(x=>x.id===id),items=$('folderItems');if(!f||!items)return false;
  $('folderViewTitle').textContent=f.name;
  const nodes=config.links.filter(x=>x.folderId===id).map((l,i)=>createTileElement(l,i));
  if(nodes.length){items.replaceChildren(...nodes)}else{
    const empty=document.createElement('div');empty.className='folderEmptyState';
    const icon=document.createElement('span');icon.className='folderEmptyIcon';icon.setAttribute('aria-hidden','true');
    const title=document.createElement('strong');title.textContent=tr('Папка пока пустая');
    const text=document.createElement('small');text.textContent=tr('Добавьте сайты и выберите эту папку при сохранении.');
    empty.append(icon,title,text);items.replaceChildren(empty);
  }
  return true;
}
function refreshOpenFolderView(){
  const modal=$('folderViewModal');if(!modal?.open)return;
  const id=modal.dataset.folderId;if(!id||!renderFolderViewContent(id))closeFolderView();
}
function openFolderView(id){
  const modal=$('folderViewModal'),card=modal?.querySelector('.folderViewCard');
  if(!modal||!card||!renderFolderViewContent(id))return;
  modal.dataset.folderId=id;
  if(modal._closeAnimation){modal._closeAnimation.cancel();modal._closeAnimation=null}
  if(card._closeAnimation){card._closeAnimation.cancel();card._closeAnimation=null}
  modal.classList.remove('closing');
  if(!modal.open)modal.showModal();
  modal.classList.add('is-open');
  modal.animate([{opacity:0},{opacity:1}],{duration:170,easing:'ease-out',fill:'both'}).finished.catch(()=>{}).finally(()=>{if(modal.open)modal.style.opacity=''})
  card.animate([{opacity:0,transform:'translateY(8px) scale(.985)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:210,easing:'cubic-bezier(.22,.8,.24,1)',fill:'both'}).finished.catch(()=>{}).finally(()=>{if(modal.open){card.style.opacity='';card.style.transform=''}})
}
function closeFolderView(){
  const modal=$('folderViewModal'),card=modal?.querySelector('.folderViewCard');if(!modal?.open||!card||modal.classList.contains('closing'))return;
  modal.classList.add('closing');
  const modalAnim=modal.animate([{opacity:1},{opacity:0}],{duration:155,easing:'ease-in',fill:'both'});
  const cardAnim=card.animate([{opacity:1,transform:'translateY(0) scale(1)'},{opacity:0,transform:'translateY(5px) scale(.992)'}],{duration:155,easing:'cubic-bezier(.4,0,1,1)',fill:'both'});
  modal._closeAnimation=modalAnim;card._closeAnimation=cardAnim;
  Promise.allSettled([modalAnim.finished,cardAnim.finished]).then(()=>{
    if(modal.open)modal.close();
    const contextMenu=$('tileContextMenu');if(contextMenu)contextMenu.hidden=true;restoreContextMenuHost();
    modal.classList.remove('is-open','closing');modal.style.opacity='';card.style.opacity='';card.style.transform='';delete modal.dataset.folderId;modal._closeAnimation=null;card._closeAnimation=null;
  });
}
function restoreContextMenuHost(){
  const m=$('tileContextMenu');
  if(m&&m.parentElement!==document.body)document.body.append(m);
}
function positionContextMenu(m,x,y){
  const folderModal=$('folderViewModal');
  const host=folderModal?.open?folderModal:document.body;
  if(m.parentElement!==host)host.append(m);
  m.hidden=false;
  m.style.left='0px';m.style.top='0px';
  const rect=m.getBoundingClientRect(),pad=8;
  m.style.left=Math.max(pad,Math.min(x,innerWidth-rect.width-pad))+'px';
  m.style.top=Math.max(pad,Math.min(y,innerHeight-rect.height-pad))+'px';
}
async function duplicateLink(link){
  if(!canZoneAccept(link.zone))return;
  const copy={...structuredClone(link),id:uid(),title:(link.title+tr(' копия')).slice(0,32)};
  if(copy.iconMode==='upload'){try{copy.iconData=link.iconData||await assetGet('icon:'+link.id);if(copy.iconData)await assetSet('icon:'+copy.id,copy.iconData)}catch(err){console.warn('Icon duplicate failed',err);copy.iconMode='initials';delete copy.iconData}}
  const before=structuredClone(config.links);config.links.push(copy);
  if(!await save()){config.links=before;await assetDelete('icon:'+copy.id).catch(()=>{});renderLinks();return}
  renderLinks();toast(tr('Ссылка продублирована'),'success');
}
async function deleteLink(link){
  if(!await customConfirm(tr('Удалить эту ссылку?'),{title:tr('Удаление ссылки'),okText:tr('Удалить'),danger:true}))return;
  const before=structuredClone(config.links);config.links=config.links.filter(x=>x.id!==link.id);
  if(!await save()){config.links=before;renderLinks();return}
  await assetDelete('icon:'+link.id).catch(()=>{});await animateTileRemoval(link.id);toast(tr('Ссылка удалена'),'success');
}
function showTileContextMenu(link,x,y){const m=$('tileContextMenu');m.replaceChildren();[[tr('Открыть'),()=>location.href=link.url],[tr('Открыть в новой вкладке'),()=>open(link.url,'_blank','noopener')],[tr('Изменить'),()=>openTile(link.id)],[tr('Дублировать'),()=>duplicateLink(link)],[tr('Удалить'),()=>deleteLink(link)]].forEach(([t,fn])=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.onclick=()=>{m.hidden=true;fn()};m.append(b)});positionContextMenu(m,x,y)}
async function chooseFolderDeleteMode(folderId){
  const folder=config.folders.find(f=>f.id===folderId);if(!folder)return null;
  const count=config.links.filter(link=>link.folderId===folderId).length;
  $('folderDeleteName').textContent=folder.name;
  $('folderDeleteCount').textContent=count?tr('Плиток внутри: {count}').replace('{count}',String(count)):tr('В папке нет плиток');
  $('folderDeleteKeep').checked=true;$('folderDeleteAll').checked=false;
  const modal=$('folderDeleteModal');if(modal.open)modal.close();modal.showModal();requestAnimationFrame(()=>modal.classList.add('is-open'));
  return new Promise(resolve=>{window.folderDeleteResolver=resolve});
}
function finishFolderDelete(mode){const modal=$('folderDeleteModal');modal.classList.remove('is-open');setTimeout(()=>{if(modal.open)modal.close()},170);const resolve=window.folderDeleteResolver;window.folderDeleteResolver=null;resolve?.(mode)}
async function deleteFolderById(folderId,{closeEditor=false}={}){
  const mode=await chooseFolderDeleteMode(folderId);if(!mode)return false;
  if(closeEditor)await closeFolderEditorAndWait();
  const beforeFolders=structuredClone(config.folders),beforeLinks=structuredClone(config.links);
  const removedLinks=config.links.filter(link=>link.folderId===folderId);
  if(mode==='all')config.links=config.links.filter(link=>link.folderId!==folderId);
  else config.links.forEach(link=>{if(link.folderId===folderId)link.folderId=''});
  config.folders=config.folders.filter(folder=>folder.id!==folderId);
  for(const zone of ZONES)normalizeZoneOrders(zone);
  if(!await save()){config.folders=beforeFolders;config.links=beforeLinks;renderLinks();return false}
  if(mode==='all')await Promise.all(removedLinks.map(link=>assetDelete('icon:'+link.id).catch(()=>{})));
  await animateTileRemoval(folderId,'folder');return true;
}
function showFolderContextMenu(folder,x,y){const m=$('tileContextMenu');m.replaceChildren();[[tr('Открыть'),()=>openFolderView(folder.id)],[tr('Изменить'),()=>openFolderEditor(folder.id)],[tr('Удалить'),()=>deleteFolderById(folder.id)]].forEach(([t,fn])=>{const b=document.createElement('button');b.type='button';b.textContent=t;b.onclick=()=>{m.hidden=true;fn()};m.append(b)});positionContextMenu(m,x,y)}
document.addEventListener('click',e=>{
  const m=$('tileContextMenu');
  if(!e.target.closest('#tileContextMenu')){
    m.hidden=true;
    if(!$('folderViewModal')?.open)restoreContextMenuHost();
  }
});
if($('addFolderBtn'))$('addFolderBtn').onclick=()=>openFolderEditor();$('closeFolderModal').onclick=$('cancelFolder').onclick=closeFolderEditor;$('folderModal').addEventListener('cancel',e=>{e.preventDefault();closeFolderEditor()});
$('folderForm').onsubmit=async e=>{e.preventDefault();const existing=editingFolderId?config.folders.find(x=>x.id===editingFolderId):null;const targetZone=ZONES.includes($('folderZone').value)?$('folderZone').value:'bottom';const item={id:editingFolderId||uid(),name:safeText($('folderName').value,32),zone:targetZone,color:validColor($('folderColor').value),order:existing&&existing.zone===targetZone&&Number.isFinite(existing.order)?existing.order:getNextZoneOrder(targetZone)};if((!existing||existing.zone!==targetZone)&&!canZoneAccept(targetZone,editingFolderId?{type:'folder',id:editingFolderId}:null))return;if(!item.name){toast(tr('Введите название папки'),'error');$('folderName').focus();return}const before=structuredClone(config.folders);if(editingFolderId){const i=config.folders.findIndex(x=>x.id===editingFolderId);if(i<0)return;config.folders[i]=item}else config.folders.push(item);if(!await save()){config.folders=before;renderLinks();return}renderLinks();closeFolderEditor();toast(tr('Папка сохранена'),'success')};
$('deleteFolder').onclick=async()=>{if(!editingFolderId)return;await deleteFolderById(editingFolderId,{closeEditor:true})};
$('folderDeleteForm').onsubmit=e=>{e.preventDefault();finishFolderDelete(new FormData(e.currentTarget).get('folderDeleteMode')||'keep')};
$('cancelFolderDelete').onclick=$('closeFolderDelete').onclick=()=>finishFolderDelete(null);
$('folderDeleteModal').addEventListener('cancel',e=>{e.preventDefault();finishFolderDelete(null)});
$('folderDeleteModal').addEventListener('click',e=>{if(e.target===$('folderDeleteModal'))finishFolderDelete(null)});
$('closeFolderView').onclick=closeFolderView;
$('folderViewModal').addEventListener('cancel',e=>{e.preventDefault();closeFolderView()});
$('folderViewModal').addEventListener('pointerdown',e=>{if(e.target===$('folderViewModal'))closeFolderView()});
$('undoSettings').onclick=async()=>{if(settingsSnapshot){const restored=structuredClone(settingsSnapshot),restoredIds=new Set((restored.settings.wallpapers||[]).map(x=>x.id));await cleanupWallpaperAssets(restoredIds,(config.settings.wallpapers||[]).map(x=>x.id));config=restored;await hydrateAssets();syncSettings();apply();settingsDirty=false;$('saveSettingsBtn').classList.remove('save-attention')}};
function normalizeSettingsSearch(value){return String(value||'').toLocaleLowerCase(localeCode()).replace(/ё/g,'е').replace(/\s+/g,' ').trim()}
function getSettingsSearchTitle(control,target){
  if(control.matches('button'))return control.textContent.trim();
  const strong=target.querySelector?.('strong');if(strong)return strong.textContent.trim();
  const clone=target.cloneNode(true);clone.querySelectorAll('input,select,option,output,button,small').forEach(el=>el.remove());
  return clone.textContent.replace(/\s+/g,' ').trim()||control.getAttribute('aria-label')||control.id;
}
function collectSettingsSearchItems(){
  const items=[],seen=new Set();
  document.querySelectorAll('.settingsBody>.settingsSection').forEach((section,sectionIndex)=>{
    const sectionName=section.querySelector('h3')?.textContent.trim()||tr('Настройки');
    const add=(title,target,keywords='')=>{title=String(title||'').replace(/\s+/g,' ').trim();if(!title||!target)return;const key=`${sectionIndex}|${title}|${target.id||target.className}`;if(seen.has(key))return;seen.add(key);items.push({title,sectionName,sectionIndex,target,search:normalizeSettingsSearch(`${title} ${sectionName} ${keywords}`)})};
    if(section.querySelector('#themePicker'))add(tr('Выбрать тему оформления'),section.querySelector('#themePicker'),tr('цвет фон тема'));
    if(section.querySelector('#bgFile'))add(tr('Загрузить собственный фон'),section.querySelector('.fileField'),tr('картинка изображение обои'));
    section.querySelectorAll('input:not([type="file"]),select,button').forEach(control=>{
      if(control.closest('.settingsNav')||control.id==='clearBg')return;
      const target=control.matches('button')?control:(control.closest('label')||control.closest('.fileField')||control.parentElement);
      add(getSettingsSearchTitle(control,target),target,control.id);
    });
  });
  return items;
}
function hideSettingsSearchResults(){const box=$('settingsSearchResults');box.hidden=true;box.replaceChildren();$('settingsSearch').setAttribute('aria-expanded','false')}
function resetSettingsSearch(){
  const input=$('settingsSearch');if(!input)return;input.value='';hideSettingsSearchResults();$('settingsNav').hidden=false;
  document.querySelectorAll('.settings-search-highlight').forEach(el=>el.classList.remove('settings-search-highlight'));
  (window.activateSettingsSection||(()=>{}))(Number.isInteger(window.activeSettingsSection)?window.activeSettingsSection:0);
}
window.resetSettingsSearch=resetSettingsSearch;
function renderSettingsSearch(query){
  const box=$('settingsSearchResults'),q=normalizeSettingsSearch(query);box.replaceChildren();
  if(!q){hideSettingsSearchResults();return}
  const words=q.split(' ').filter(Boolean);const matches=collectSettingsSearchItems().filter(item=>words.every(word=>item.search.includes(word))).slice(0,12);
  if(!matches.length){const empty=document.createElement('div');empty.className='settingsSearchEmpty';empty.textContent=tr('Настройка не найдена');box.append(empty)}
  else matches.forEach(item=>{const button=document.createElement('button');button.type='button';button.className='settingsSearchResult';button.setAttribute('role','option');const title=document.createElement('strong');title.textContent=item.title;const section=document.createElement('small');section.textContent=item.sectionName;button.append(title,section);button.onclick=()=>{hideSettingsSearchResults();$('settingsNav').hidden=false;(window.activateSettingsSection||(()=>{}))(item.sectionIndex);document.querySelectorAll('.settings-search-highlight').forEach(el=>el.classList.remove('settings-search-highlight'));item.target.classList.add('settings-search-highlight');requestAnimationFrame(()=>item.target.scrollIntoView({block:'center',behavior:'smooth'}));setTimeout(()=>item.target.classList.remove('settings-search-highlight'),1800)};box.append(button)});
  box.hidden=false;$('settingsSearch').setAttribute('aria-expanded','true');
}
$('settingsSearch').addEventListener('input',e=>renderSettingsSearch(e.target.value));
$('settingsSearch').addEventListener('keydown',e=>{
  if(e.key==='Enter'){
    e.preventDefault();
    e.stopPropagation();
    const first=$('settingsSearchResults').querySelector('button');
    if(first)first.click();
    else renderSettingsSearch(e.currentTarget.value);
  }else if(e.key==='Escape'){
    e.preventDefault();resetSettingsSearch();e.stopPropagation();
  }else if(e.key==='ArrowDown'){
    const first=$('settingsSearchResults').querySelector('button');if(first){e.preventDefault();first.focus()}
  }
});
document.addEventListener('click',e=>{if(!e.target.closest('.settingsSearchWrap'))hideSettingsSearchResults()});
$('clearHistorySettings').onclick=clearSearchHistory;
async function loadProfiles(){try{profiles=(await chrome.storage.local.get(PROFILES_KEY))[PROFILES_KEY]||{}}catch{profiles={}}renderProfiles()}
function renderProfiles(){const s=$('profileSelect');if(!s)return;const current=s.value;s.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent=tr('Выберите профиль');s.append(empty);for(const name of Object.keys(profiles)){const option=document.createElement('option');option.value=name;option.textContent=name;s.append(option)}s.value=profiles[current]?current:'';window.refreshAllCustomSelects?.()}
$('saveProfileBtn').onclick=async()=>{const name=safeText($('profileName').value,32);if(!name){toast(tr('Введите название профиля'),'error');return}profiles[name]=createProfileSnapshot();await chrome.storage.local.set({[PROFILES_KEY]:profiles});renderProfiles();$('profileSelect').value=name;window.refreshAllCustomSelects?.();toast(tr('Профиль сохранён'),'success')};
$('applyProfileBtn').onclick=()=>{const name=$('profileSelect').value;if(!profiles[name])return;config=profileToConfig(profiles[name]);syncSettings();apply();settingsDirty=true;$('saveSettingsBtn').classList.add('save-attention');toast(profiles[name]?.profileFormatVersion===PROFILE_FORMAT_VERSION?tr('Профиль применён'):tr('Старый профиль применён в совместимом режиме'),'success')};
$('deleteProfileBtn').onclick=async()=>{const name=$('profileSelect').value;if(!name||!await customConfirm(currentLanguage==='ru'?`Удалить профиль «${name}»?`:`Delete profile “${name}”?`,{title:tr('Удаление профиля'),okText:tr('Удалить'),danger:true}))return;delete profiles[name];await chrome.storage.local.set({[PROFILES_KEY]:profiles});renderProfiles()};
window.addEventListener('resize',fitSearchSuggestions,{passive:true});
